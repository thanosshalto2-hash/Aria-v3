#!/usr/bin/env python3
"""
Mavis — PC voice controller.
Listens on your laptop mic, controls your Android phone over ADB (USB or WiFi).

Setup: see README.md in this folder.
Run:   python mavis_pc.py
       python mavis_pc.py --text        # text mode
       python mavis_pc.py --device 192.168.1.42:5555   # wireless ADB
"""

import os
import sys
import json
import queue
import subprocess
import time
import threading
from datetime import datetime
from pathlib import Path

# allow running next to brain.py
sys.path.insert(0, os.path.dirname(__file__))
from brain import Brain, Intent  # noqa  (the local brain.py re-exports from termux)


# ---- config ----
VOSK_MODEL_PATH = os.path.expanduser("~/vosk-model")
SAMPLE_RATE = 16000
ADB = "adb"  # adb binary, must be in PATH
WAKE_WORDS = {"mavis", "hey mavis", "okay mavis", "ok mavis"}
NOTES_FILE = os.path.expanduser("~/.mavis/notes.txt")
TODO_FILE = os.path.expanduser("~/.mavis/todo.txt")
CONTACTS_FILE = os.path.expanduser("~/.mavis/contacts.json")


# ---- TTS (PC, local) ----
def speak(text: str):
    if not text:
        return
    print(f"Mavis: {text}")
    try:
        import pyttsx3
        e = pyttsx3.init()
        e.say(text)
        e.runAndWait()
        e.stop()
    except Exception as e:
        print(f"[tts-fail] {e}")


# ---- ADB helpers ----
def adb(args, timeout=10, check=False):
    cmd = [ADB] + (["-s", os.environ["MAVIS_DEVICE"]] if "MAVIS_DEVICE" in os.environ else []) + args
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        if check and r.returncode != 0:
            print(f"[adb-err] {' '.join(cmd)} -> {r.stderr.strip()}")
        return r
    except subprocess.TimeoutExpired:
        print(f"[adb-timeout] {' '.join(cmd)}")
        return None
    except FileNotFoundError:
        print("[adb-missing] Install adb (e.g. `brew install android-platform-tools` or `apt install adb`).")
        return None


def adb_shell(cmdline, timeout=10):
    return adb(["shell"] + cmdline.split(), timeout=timeout)


# ---- handlers ----
def battery() -> str:
    r = adb_shell("dumpsys battery | grep level")
    if r and r.stdout:
        for line in r.stdout.splitlines():
            if "level:" in line:
                pct = line.split(":")[1].strip()
                return f"Battery is at {pct}%."
    return "I can't read the battery."


def call(name: str) -> str:
    number = _resolve_contact(name) or name
    digits = "".join(c for c in number if c.isdigit() or c == "+")
    if not digits:
        return f"I don't have a number for {name}."
    r = adb_shell(f"am start -a android.intent.action.CALL -d tel:{digits}")
    return f"Calling {digits}." if r and r.returncode == 0 else f"Couldn't call {digits}."


def sms(name: str, msg: str) -> str:
    number = _resolve_contact(name) or name
    # ADB has no direct SMS API; open the SMS app with prefilled fields.
    r = adb_shell(f"am start -a android.intent.action.SENDTO -d sms:{number} --es sms_body '{msg.replace(chr(39), chr(39)+chr(92)+chr(39))}'")
    return f"Opening text to {number}." if r and r.returncode == 0 else f"Couldn't text {number}."


def whatsapp(name: str, msg: str) -> str:
    number = _resolve_contact(name) or name
    digits = "".join(c for c in number if c.isdigit())
    url = f"https://wa.me/{digits}?text={msg}"
    r = adb_shell(f"am start -a android.intent.action.VIEW -d '{url}'")
    return f"Opening WhatsApp for {number}." if r and r.returncode == 0 else f"Couldn't open WhatsApp."


def set_alarm(time_str: str) -> str:
    try:
        h, m = time_str.split(":")
        h, m = int(h), int(m)
        r = adb_shell(f"am start -a android.intent.action.SET_ALARM --ei android.intent.extra.alarm.HOUR {h} --ei android.intent.extra.alarm.MINUTES {m}")
        return f"Alarm set for {time_str}." if r and r.returncode == 0 else f"Couldn't set alarm for {time_str}."
    except Exception:
        return "I need a time like 7:30."


def set_reminder(delay: int, task: str) -> str:
    if delay <= 0:
        return "Tell me 'in 5 minutes to ...' please."
    def _fire():
        time.sleep(delay)
        speak(f"Reminder: {task}")
    threading.Thread(target=_fire, daemon=True).start()
    return f"I'll remind you to {task} in {_humanize(delay)}."


def set_timer(duration: int) -> str:
    if duration <= 0:
        return "How long?"
    def _fire():
        time.sleep(duration)
        adb_shell("cmd notification post -t 'Timer' mavis_timer 'Your timer is up!'")
        speak("Timer is up!")
    threading.Thread(target=_fire, daemon=True).start()
    return f"Timer started for {_humanize(duration)}."


def open_app(app: str) -> str:
    aliases = {
        "youtube": "com.google.android.youtube", "chrome": "com.android.chrome",
        "gmail": "com.google.android.gm", "maps": "com.google.android.apps.maps",
        "settings": "com.android.settings", "camera": "com.android.camera",
        "calculator": "com.android.calculator2", "calendar": "com.google.android.calendar",
        "photos": "com.google.android.apps.photos", "play store": "com.android.vending",
        "messages": "com.google.android.apps.messaging", "phone": "com.android.dialer",
        "contacts": "com.android.contacts", "clock": "com.google.android.deskclock",
        "spotify": "com.spotify.music", "instagram": "com.instagram.android",
        "facebook": "com.facebook.katana", "twitter": "com.twitter.android",
        "x": "com.twitter.android", "telegram": "org.telegram.messenger",
        "whatsapp": "com.whatsapp", "files": "com.android.documentsui",
        "notes": "com.google.android.keep",
    }
    pkg = aliases.get(app.lower(), app)
    # Try monkey first (works for most apps)
    r = adb_shell(f"monkey -p {pkg} -c android.intent.category.LAUNCHER 1")
    if r and r.returncode != 0:
        # Try am start
        r = adb_shell(f"am start -n {pkg}/.MainActivity")
    return f"Opening {app}."


def web_search(query: str) -> str:
    from urllib.parse import quote
    url = f"https://www.google.com/search?q={quote(query)}"
    adb_shell(f"am start -a android.intent.action.VIEW -d '{url}'")
    return f"Searching for {query}."


def toggle_flashlight(on: bool) -> str:
    # Most phones: cmd flashlight
    r = adb_shell(f"cmd flashlight {'on' if on else 'off'}")
    if r and r.returncode == 0:
        return f"Flashlight {'on' if on else 'off'}."
    # fallback: open torch app
    adb_shell("am start -n com.intangibleobject.flashlight/.MainActivity")
    return f"Tried flashlight."


def toggle_wifi(on: bool) -> str:
    r = adb_shell(f"svc wifi {'enable' if on else 'disable'}")
    return f"WiFi {'on' if on else 'off'}." if r and r.returncode == 0 else "Couldn't toggle WiFi."


def toggle_bluetooth(on: bool) -> str:
    r = adb_shell(f"svc bluetooth {'enable' if on else 'disable'}")
    return f"Bluetooth {'on' if on else 'off'}." if r and r.returncode == 0 else "Couldn't toggle Bluetooth."


def set_volume(mute: bool) -> str:
    mode = 0 if mute else 2  # silent : normal
    r = adb_shell(f"settings put global mode_ringer {mode}")
    return f"Phone {'muted' if mute else 'unmuted'}." if r and r.returncode == 0 else "Couldn't change ringer."


def adjust_volume(direction: str) -> str:
    key = "24" if direction == "up" else "25"  # KEYCODE_VOLUME_UP / DOWN
    for _ in range(3):
        adb_shell(f"input keyevent {key}")
    return f"Volume {direction}."


def open_camera() -> str:
    adb_shell("am start -a android.media.action.IMAGE_CAPTURE")
    return "Opening camera."


def screenshot() -> str:
    out = "/sdcard/mavis_screenshot.png"
    r = adb_shell(f"screencap -p {out}")
    if r and r.returncode == 0:
        # pull to PC
        local = os.path.expanduser("~/mavis_screenshot.png")
        adb(["pull", out, local])
        adb_shell(f"rm {out}")
        return f"Screenshot saved to {local}."
    return "Couldn't take screenshot."


def add_note(text: str) -> str:
    os.makedirs(os.path.dirname(NOTES_FILE), exist_ok=True)
    with open(NOTES_FILE, "a") as f:
        f.write(f"[{datetime.now():%Y-%m-%d %H:%M}] {text}\n")
    return "Noted."


def read_notes() -> str:
    if not os.path.exists(NOTES_FILE):
        return "No notes yet."
    with open(NOTES_FILE) as f:
        notes = f.read().strip().splitlines()
    return "Your last notes: " + " ... ".join(notes[-3:]) if notes else "No notes yet."


def clear_notes() -> str:
    if os.path.exists(NOTES_FILE): os.remove(NOTES_FILE)
    return "Notes cleared."


def add_todo(task: str) -> str:
    os.makedirs(os.path.dirname(TODO_FILE), exist_ok=True)
    with open(TODO_FILE, "a") as f:
        f.write(f"- {task}\n")
    return f"Added: {task}."


def list_todo() -> str:
    if not os.path.exists(TODO_FILE):
        return "Your to-do list is empty."
    with open(TODO_FILE) as f:
        items = [l.strip() for l in f if l.strip()]
    return "You have " + "; ".join(items[:5]) if items else "Your to-do list is empty."


# ---- contacts ----
def _resolve_contact(name: str) -> str | None:
    if not os.path.exists(CONTACTS_FILE):
        return None
    try:
        with open(CONTACTS_FILE) as f:
            contacts = json.load(f)
        return contacts.get(name.lower().strip())
    except Exception:
        return None


# ---- math (delegated to brain's safe_calc) ----
from brain import safe_calc  # re-use
import random

JOKES = [
    "Why don't scientists trust atoms? Because they make up everything.",
    "I told my computer I needed a break, and it said 'no problem, I'll go to sleep.'",
    "Why did the developer go broke? Because he used up all his cache.",
    "There are 10 kinds of people in the world: those who understand binary, and those who don't.",
    "Why do programmers prefer dark mode? Because light attracts bugs.",
]
FACTS = [
    "Honey never spoils. Archaeologists have found 3000-year-old honey in Egyptian tombs that's still edible.",
    "A group of flamingos is called a 'flamboyance'.",
    "Bananas are berries, but strawberries aren't.",
    "Octopuses have three hearts and blue blood.",
    "The Eiffel Tower can grow up to 6 inches taller in summer due to thermal expansion.",
]


# ---- intent dispatch ----
def handle(intent: Intent) -> str:
    name, p = intent.name, intent.params
    return {
        "greet":                lambda: random.choice(["Hey! What's up?", "Hi!", "Hello!"]),
        "smalltalk_how_are_you":lambda: "Doing great. What do you need?",
        "get_time":             lambda: f"It's {datetime.now():%I:%M %p}.",
        "get_date":             lambda: f"Today is {datetime.now():%A, %B %d, %Y}.",
        "get_battery":          battery,
        "calc":                 lambda: f"That's {safe_calc(p.get('expr',''))}.",
        "call_contact":         lambda: call(p.get("name","")),
        "send_sms":             lambda: sms(p.get("name",""), p.get("message","")),
        "send_whatsapp":        lambda: whatsapp(p.get("name",""), p.get("message","")),
        "set_alarm":            lambda: set_alarm(p.get("time","")),
        "set_reminder":         lambda: set_reminder(int(p.get("delay") or 0), p.get("task","")),
        "set_timer":            lambda: set_timer(int(p.get("duration") or 0)),
        "open_app":             lambda: open_app(p.get("app","")),
        "web_search":           lambda: web_search(p.get("query","")),
        "add_note":             lambda: add_note(p.get("text","")),
        "read_notes":           read_notes,
        "clear_notes":          clear_notes,
        "add_todo":             lambda: add_todo(p.get("task","")),
        "list_todo":            list_todo,
        "toggle_flashlight":    lambda: toggle_flashlight(p.get("on") is True),
        "toggle_wifi":          lambda: toggle_wifi(p.get("on") is True),
        "toggle_bluetooth":     lambda: toggle_bluetooth(p.get("on") is True),
        "set_volume":           lambda: set_volume(p.get("mute") is True),
        "adjust_volume":        lambda: adjust_volume("up"),
        "open_camera":          open_camera,
        "screenshot":           screenshot,
        "joke":                 lambda: random.choice(JOKES),
        "fact":                 lambda: random.choice(FACTS),
        "help":                 lambda: ("I can: calls, texts, apps, alarms, reminders, timers, "
                                       "notes, to-do, web search, screenshots, flashlight, WiFi, "
                                       "Bluetooth, time, date, battery, jokes, facts. Say goodbye to quit."),
        "thanks":               lambda: "Anytime!",
        "exit":                 lambda: "__EXIT__",
    }.get(name, lambda: intent.reply or "I didn't quite get that.")()


def _humanize(s: int) -> str:
    if s < 60: return f"{s} seconds"
    if s < 3600: return f"{s//60} minutes"
    h, m = divmod(s//60, 60)
    return f"{h} hour{'s' if h!=1 else ''} {m} minutes" if m else f"{h} hour{'s' if h!=1 else ''}"


# ---- audio loop ----
def stt_loop(brain: Brain, on_utterance):
    try:
        from vosk import Model, KaldiRecognizer
        import sounddevice as sd
    except Exception as e:
        print(f"[error] pip install vosk sounddevice  ({e})")
        return
    if not os.path.isdir(VOSK_MODEL_PATH):
        print(f"[error] Vosk model not found at {VOSK_MODEL_PATH}")
        print("Download: curl -L -o ~/vosk-model.zip https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip")
        print("         unzip ~/vosk-model.zip -d ~ && mv ~/vosk-model-small-en-us-0.15 ~/vosk-model")
        return

    model = Model(VOSK_MODEL_PATH)
    rec = KaldiRecognizer(model, SAMPLE_RATE)
    q = queue.Queue()
    listening = False

    def cb(indata, frames, time_info, status):
        if status: print(status, file=sys.stderr)
        q.put(bytes(indata))

    print("[mavis-PC] listening for 'mavis'...  (Ctrl+C to stop)")
    try:
        with sd.RawInputStream(samplerate=SAMPLE_RATE, blocksize=8000, dtype="int16",
                               channels=1, callback=cb):
            while True:
                data = q.get()
                if rec.AcceptWaveform(data):
                    res = json.loads(rec.Result())
                    text = (res.get("text") or "").strip().lower()
                    if not text: continue
                    if not listening:
                        if any(w in text for w in WAKE_WORDS):
                            listening = True
                            speak("Yes?")
                            print("[wake] listening for command...")
                    else:
                        listening = False
                        print(f"[heard] {text}")
                        on_utterance(text)
    except KeyboardInterrupt:
        print("\n[mavis-PC] bye.")


def repl(brain: Brain):
    speak("Mavis PC online. Type a command, or 'goodbye' to quit.")
    while True:
        try:
            text = input("you> ").strip()
        except (EOFError, KeyboardInterrupt): break
        if not text: continue
        intent = brain.parse(text)
        reply = handle(intent)
        if reply == "__EXIT__":
            speak("Goodbye.")
            break
        speak(reply)


def main():
    brain = Brain()

    # parse --device
    if "--device" in sys.argv:
        i = sys.argv.index("--device")
        if i + 1 < len(sys.argv):
            os.environ["MAVIS_DEVICE"] = sys.argv[i+1]
            print(f"[mavis-PC] using device {sys.argv[i+1]}")

    if "--text" in sys.argv:
        repl(brain)
    else:
        def on_utt(text):
            intent = brain.parse(text)
            reply = handle(intent)
            if reply == "__EXIT__":
                speak("Goodbye.")
                sys.exit(0)
            speak(reply)
        stt_loop(brain, on_utt)


if __name__ == "__main__":
    main()

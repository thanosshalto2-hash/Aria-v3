# Mavis PC Controller

> Control your phone with your voice, from your laptop. **No APK, no app install on phone, no cloud.** Uses ADB.

## 1. Install prerequisites

### On your PC

```bash
pip install vosk sounddevice pyttsx3

# macOS:
brew install android-platform-tools

# Ubuntu / Debian:
sudo apt install adb

# Windows: download platform-tools from https://developer.android.com/studio/releases/platform-tools
```

### On your phone

1. Enable Developer options: Settings → About phone → tap "Build number" 7 times
2. Enable USB debugging: Settings → System → Developer options → USB debugging ON
3. Plug into PC with a USB cable
4. Accept the "Allow USB debugging" popup on phone

## 2. Set up

```bash
cd ~  # or wherever
curl -L -o vosk-model.zip https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip
unzip vosk-model.zip && mv vosk-model-small-en-us-0.15 vosk-model && rm vosk-model.zip
```

## 3. Run

```bash
# Plug phone in (USB), or use wireless ADB:
adb tcpip 5555
adb connect <phone-ip>:5555     # e.g. 192.168.1.42:5555

# Then:
cd mavis-assistant/pc-controller
python mavis_pc.py                          # first available device
python mavis_pc.py --device 192.168.1.42:5555   # specific device
python mavis_pc.py --text                   # no mic, type commands
```

## 4. Try

Say "**hey mavis**" then any command. Or type in text mode.

| Say | Does |
|---|---|
| `what is the time` | Reads PC clock |
| `battery` | Phone battery % |
| `call mom` | Dials mom |
| `text John: running late` | Opens SMS to John |
| `set alarm for 7am` | Sets phone alarm |
| `remind me in 10 minutes to stretch` | PC reminder |
| `open youtube` | Opens YouTube on phone |
| `search for python tutorials` | Google search on phone |
| `turn on flashlight` | Phone torch |
| `take a screenshot` | Saves to `~/mavis_screenshot.png` |
| `note: meeting at 3pm` | Saves to `~/.mavis/notes.txt` |
| `tell me a joke` | PC tells a joke |

## 5. Wireless ADB (no USB cable)

One-time setup:

```bash
adb tcpip 5555           # phone listens on 5555
adb connect <ip>:5555    # PC connects
adb devices              # should list ip:5555 as "device"
```

Now `python mavis_pc.py --device 192.168.1.42:5555` works over WiFi.

> Phone and PC must be on the same network.

## Customizing contacts

Create `~/.mavis/contacts.json`:

```json
{
  "mom":  "+15551234567",
  "dad":  "+15559876543",
  "john": "+15551112222"
}
```

Then "call mom" dials your mom's real number.

## How it works

```
[PC mic] → Vosk STT (local) → brain.parse() → adb shell command → phone executes
```

All the hard work happens on the phone via `adb shell`. The PC just transcribes your speech and sends ADB commands. **Phone never knows about an API or cloud.**

## Troubleshooting

**"adb: command not found"** — Install platform-tools (see step 1).

**"unauthorized"** — Accept the USB debugging popup on phone. If stuck: revoke all in Developer options, then plug in again.

**"device offline"** — `adb kill-server && adb start-server && adb devices`. For wireless: `adb disconnect && adb connect <ip>:5555`.

**No mic input** — Check your system mic is the default. On macOS, give Terminal mic permission.

**Vosk model not found** — Make sure `~/vosk-model` exists (not `~/vosk-model-small-en-us-0.15`).

**"Couldn't call X"** — Some Android versions block adb-initiated calls. Use the dialer-open fallback: `am start -a android.intent.action.DIAL -d tel:1234` (in `call()`).

**TTS doesn't work** — pyttsx3 uses your OS TTS. On Linux you may need `espeak`: `sudo apt install espeak`.

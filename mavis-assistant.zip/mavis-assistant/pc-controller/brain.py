"""
Mavis PC brain — re-uses the Termux brain.py for parsing,
adds a small math helper.
"""
import sys, os
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(_HERE, "..", "termux"))

# Import via importlib to avoid self-shadowing.
import importlib.util as _ilu
spec = _ilu.spec_from_file_location("_termux_brain",
    os.path.join(_HERE, "..", "termux", "brain.py"))
_mod = _ilu.module_from_spec(spec)
spec.loader.exec_module(_mod)
Brain = _mod.Brain
Intent = _mod.Intent

import ast


def safe_calc(expr: str) -> str:
    ops = {ast.Add: lambda a, b: a + b, ast.Sub: lambda a, b: a - b,
           ast.Mult: lambda a, b: a * b, ast.Div: lambda a, b: a / b,
           ast.Pow: lambda a, b: a ** b, ast.Mod: lambda a, b: a % b,
           ast.USub: lambda a: -a}
    def _e(n):
        if isinstance(n, ast.Num): return n.n
        if isinstance(n, ast.BinOp): return ops[type(n.op)](_e(n.left), _e(n.right))
        if isinstance(n, ast.UnaryOp): return ops[type(n.op)](_e(n.operand))
        raise ValueError("bad")
    s = expr.lower()
    s = s.replace("plus", "+").replace("minus", "-").replace("times", "*").replace("multiplied by", "*")
    s = s.replace("divided by", "/").replace("x", "*")
    for kw in ["what is", "what's", "calculate", "compute"]:
        s = s.replace(kw, "")
    s = s.strip()
    try:
        return str(_e(ast.parse(s, mode="eval").body))
    except Exception as e:
        return f"err: {e}"


if __name__ == "__main__":
    b = Brain()
    for t in ["hey mavis set alarm for 7am", "what is 25 times 17", "call mom"]:
        print(t, "->", b.parse(t))

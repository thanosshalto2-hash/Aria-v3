# Mavis — Personal Voice Assistant (No API, No Cloud)

A fully self-contained, offline voice assistant. **No LLM, no API keys, no cloud calls.** Pure rule-based engine, runs 100% on-device.

Pick the version that fits you:

| Option | Platform | Difficulty | Best for |
|--------|----------|------------|----------|
| **A. Android APK** | Android phone | Medium (build APK) | True on-phone assistant |
| **B. Termux** | Android (no build) | Easy | Run scripts directly on phone |
| **C. PC Controller** | PC + phone over ADB | Easiest | Control phone from laptop |

---

## What it can do (all versions)

- **Voice control** — wake word "Hey Mavis" → speak → action
- **Calls & SMS** — "call mom", "send text to John: running late"
- **WhatsApp** — "whatsapp hello to Sarah"
- **Alarms & reminders** — "set alarm for 7am", "remind me in 10 minutes to drink water"
- **Apps** — "open youtube", "open chrome", "open settings"
- **Web search** — opens browser with your query (no API)
- **Camera, flashlight, WiFi, Bluetooth** — toggle via voice
- **Calculator** — "what is 25 times 17"
- **Notes & to-do** — saves locally as files
- **Time, date, battery, jokes, facts** — built-in responses
- **Timer & stopwatch** — "set timer for 5 minutes"

---

## How "no API" works

- **STT (speech-to-text):** Vosk (offline, ~50MB model, MIT license) — runs locally
- **TTS (text-to-speech):** Android's built-in `TextToSpeech` engine — no network
- **Brain:** pure Python/Kotlin rule engine — pattern matching, no neural net
- **Wake word:** Porcupine or simple energy-based detector — local

---

## Quick start

### Option B (Termux — easiest, 5 min setup)

```bash
# 1. Install Termux from F-Droid (NOT Play Store)
# 2. Open Termux, paste:
pkg update -y && pkg install python termux-api -y
pip install vosk sounddevice

# 3. Get a Vosk model (English, small):
cd ~
curl -L -o vosk-model.zip https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip
unzip vosk-model.zip && mv vosk-model-small-en-us-0.15 vosk-model

# 4. Install Termux:API app from F-Droid (grants call/SMS/alarm access)
# 5. Run:
git clone <this-repo> mavis-assistant
cd mavis-assistant/termux
python mavis.py
```

Say **"hey mavis"** then your command.

---

### Option C (PC controller — easiest of all)

```bash
# 1. Install ADB on PC, enable USB debugging on phone
# 2. Plug phone in, run:
pip install vosk sounddevice pyttsx3
python pc-controller/mavis_pc.py
```

---

### Option A (Android APK — most powerful)

See `android-app/README.md`. Build with Android Studio or `gradle`.

---

## Architecture

```
┌─────────────┐
│  Microphone │ → Vosk STT (local)
└──────┬──────┘
       │ text
       ▼
┌─────────────────────┐
│  Rule Engine (brain)│ → pattern match → intent
└──────┬──────────────┘
       │ intent + params
       ▼
┌─────────────────────┐
│  Action Handlers    │ → call / sms / app / alarm / ...
└──────┬──────────────┘
       │ result
       ▼
┌─────────────────────┐
│  TTS (local)        │ → speaker
└─────────────────────┘
```

---

## Files

```
mavis-assistant/
├── README.md                  ← you are here
├── android-app/               ← Option A: Kotlin APK
│   ├── app/
│   │   ├── src/main/
│   │   │   ├── java/com/mavis/assistant/
│   │   │   │   ├── MainActivity.kt
│   │   │   │   ├── MavisService.kt       (foreground + wake word)
│   │   │   │   ├── stt/SttEngine.kt      (Vosk wrapper)
│   │   │   │   ├── tts/TtsEngine.kt
│   │   │   │   ├── brain/IntentRouter.kt (rule engine)
│   │   │   │   ├── brain/Handlers.kt     (all actions)
│   │   │   │   └── brain/Brain.kt
│   │   │   ├── res/
│   │   │   └── AndroidManifest.xml
│   │   └── build.gradle
│   ├── build.gradle
│   ├── settings.gradle
│   └── gradle.properties
├── termux/                    ← Option B: Python
│   ├── mavis.py               (main loop)
│   ├── brain.py               (rule engine)
│   ├── stt.py                 (Vosk)
│   ├── tts.py                 (Termux TTS)
│   ├── actions.py             (Termux:API calls)
│   └── requirements.txt
├── pc-controller/             ← Option C: PC Python
│   ├── mavis_pc.py
│   ├── brain.py
│   ├── stt.py
│   ├── tts.py
│   ├── adb_actions.py
│   └── requirements.txt
└── docs/
    ├── SETUP.md
    ├── CUSTOMIZE.md
    └── ADD_COMMANDS.md
```

---

## License

MIT. Built by Mavis.

#!/data/data/com.termux/files/usr/bin/bash
# Mavis installer for Termux (Android).
# Run inside Termux: bash install.sh

set -e

echo "==> Mavis installer (Termux)"
echo

# 1. Update Termux packages
echo "[1/5] Updating Termux packages..."
pkg update -y
pkg upgrade -y

# 2. Install system deps
echo "[2/5] Installing system dependencies..."
pkg install -y python termux-api git curl unzip

# 3. Install Python deps
echo "[3/5] Installing Python packages..."
pip install --upgrade pip
pip install vosk sounddevice

# 4. Download Vosk English model (small, ~40MB)
echo "[4/5] Downloading Vosk speech model..."
cd ~
if [ ! -d "vosk-model-small-en-us-0.15" ] && [ ! -d "vosk-model" ]; then
  curl -L -o vosk-model.zip https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip
  unzip -q vosk-model.zip
  rm vosk-model.zip
  mv vosk-model-small-en-us-0.15 vosk-model
else
  echo "  Vosk model already present, skipping."
fi

# 5. Grant storage access (for screenshots/notes)
echo "[5/5] Setting up storage..."
mkdir -p ~/.mavis
termux-setup-storage 2>/dev/null || true

# 6. Create contacts template
cat > ~/.mavis/contacts.json <<'EOF'
{
  "mom": "+1234567890",
  "dad": "+1234567890",
  "john": "+1234567890"
}
EOF

echo
echo "==> Done!"
echo
echo "IMPORTANT: Install the 'Termux:API' app from F-Droid (NOT Play Store)."
echo "  https://f-droid.org/en/packages/com.termux.api/"
echo
echo "Open it once and grant all permissions (calls, SMS, storage, etc)."
echo
echo "Then run Mavis:"
echo "  python mavis.py            # voice mode"
echo "  python mavis.py --text     # text mode (for testing)"
echo
echo "Say 'hey mavis' followed by your command."
echo "Examples:"
echo "  hey mavis set alarm for 7am"
echo "  hey mavis call mom"
echo "  hey mavis remind me in 10 minutes to drink water"
echo "  hey mavis what is the time"
echo

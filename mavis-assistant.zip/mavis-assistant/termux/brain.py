"""
Mavis Brain — Pure rule-based intent engine.
No LLM, no API, no network. Pattern matching + slot extraction.

Usage:
    from brain import Brain
    brain = Brain()
    intent = brain.parse("set an alarm for 7 am")
    # Intent(name="set_alarm", params={"time": "07:00"}, confidence=0.95)
"""

import re
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple


class Intent:
    def __init__(self, name: str, params: Dict, confidence: float, reply: Optional[str] = None):
        self.name = name
        self.params = params
        self.confidence = confidence
        self.reply = reply  # if set, brain has a direct answer (math, time, etc.)

    def __repr__(self):
        return f"Intent({self.name}, {self.params}, conf={self.confidence:.2f})"


class Brain:
    def __init__(self):
        self.commands: List[Dict] = []  # list of {patterns, intent, params_extractor}
        self._register_defaults()

    # ---- public API ----
    def parse(self, text: str) -> Intent:
        """Return best-matching Intent for free-form text."""
        text = self._normalize(text)
        best, best_score = None, 0.0
        for cmd in self.commands:
            for pat in cmd["patterns"]:
                m = re.search(pat, text)
                if m:
                    # score: longer pattern match = higher
                    score = len(m.group(0)) / max(len(text), 1)
                    if score > best_score:
                        best_score = score
                        best = (cmd, m)
        if best is None:
            return Intent("unknown", {"text": text}, 0.0,
                          "Sorry, I didn't catch that. Try 'help' to see what I can do.")
        cmd, m = best
        params = cmd["extract"](m) if cmd.get("extract") else {}
        reply = cmd.get("reply")
        return Intent(cmd["intent"], params, best_score, reply)

    def register(self, patterns: List[str], intent: str,
                 extract=None, reply: Optional[str] = None):
        """Add a custom command at runtime."""
        self.commands.append({
            "patterns": patterns, "intent": intent,
            "extract": extract, "reply": reply,
        })

    # ---- internals ----
    def _normalize(self, text: str) -> str:
        t = text.lower().strip()
        # strip wake word if present
        for w in ["hey mavis", "okay mavis", "ok mavis", "mavis", "hey assistant"]:
            t = t.replace(w, "").strip()
        # expand a few common contractions
        repl = {
            "what's": "what is", "it's": "it is", "let's": "let us",
            "i'm": "i am", "don't": "do not", "can't": "cannot",
        }
        for k, v in repl.items():
            t = t.replace(k, v)
        return t

    def _register_defaults(self):
        C = self.commands

        # --- Greetings ---
        C.append({
            "patterns": [r"\b(hi|hello|hey|yo|howdy|hola)\b"],
            "intent": "greet",
            "reply": random_greeting(),
        })

        # --- How are you ---
        C.append({
            "patterns": [r"how (are|r) you", r"how('?s| is) it going", r"what's up"],
            "intent": "smalltalk_how_are_you",
            "reply": "Doing great, thanks for asking. What's on your mind?",
        })

        # --- Time ---
        C.append({
            "patterns": [r"what(?:'s| is) the time", r"tell me the time", r"current time", r"what time is it"],
            "intent": "get_time",
            "reply": None,  # handler will fill
        })

        # --- Date ---
        C.append({
            "patterns": [r"what(?:'s| is|s| are)? (the )?date",
                         r"what day is (it|today)",
                         r"today(?:'s|s)? date",
                         r"current date"],
            "intent": "get_date",
            "reply": None,
        })

        # --- Battery ---
        C.append({
            "patterns": [r"battery (level|status|how much)", r"how much battery"],
            "intent": "get_battery",
            "reply": None,
        })

        # --- Math ---
        C.append({
            "patterns": [r"what(?:'s| is) (.+?)\s+(plus|minus|times|divided by|multiplied by|x|\+|-|\*|/)\s+(.+)",
                         r"calculate (.+)", r"compute (.+)"],
            "intent": "calc",
            "extract": lambda m: {
                "expr": m.group(0) if m.lastindex and m.lastindex == 3 else m.group(1)
            },
        })

        # --- Call ---
        C.append({
            "patterns": [r"call (\w[\w\s]*?)(?:\s+on (?:their )?(?:mobile|cell|phone))?$",
                         r"make a call to (\w[\w\s]*)", r"phone (\w[\w\s]*)", r"dial (\w[\w\s]*)"],
            "intent": "call_contact",
            "extract": lambda m: {"name": m.group(1).strip()},
        })

        # --- SMS ---
        C.append({
            "patterns": [
                r"send (?:a )?(?:text|sms|message) to (\w[\w\s]*?): (.+)",
                r"text (\w[\w\s]*?): (.+)",
                r"message (\w[\w\s]*?): (.+)",
                r"send (?:a )?(?:text|sms|message) to (\w[\w\s]*?) saying (.+)",
            ],
            "intent": "send_sms",
            "extract": lambda m: {
                "name": (m.group(1) or "").strip(),
                "message": (m.group(2) or m.group(1) or "").strip() if m.lastindex and m.lastindex >= 2 else "",
            },
        })

        # --- WhatsApp ---
        C.append({
            "patterns": [
                r"whatsapp (.+?) to (\w[\w\s]*)",
                r"send whatsapp to (\w[\w\s]*?): (.+)",
                r"message (\w[\w\s]*?) on whatsapp: (.+)",
            ],
            "intent": "send_whatsapp",
            "extract": lambda m: {
                "name": (m.group(2) or m.group(1) or "").strip(),
                "message": (m.group(1) or m.group(2) or "").strip() if m.lastindex and m.lastindex >= 2 else "",
            },
        })

        # --- Alarm ---
        C.append({
            "patterns": [
                r"set (?:an? )?alarm (?:for )?(.+)",
                r"wake me up at (.+)",
                r"alarm (?:at )?(.+)",
            ],
            "intent": "set_alarm",
            "extract": lambda m: {"time": _parse_time(m.group(1).strip())},
        })

        # --- Reminder ---
        C.append({
            "patterns": [
                r"remind me (?:in|after) (.+?) to (.+)",
                r"set (?:a )?reminder (?:for )?(.+?) to (.+)",
                r"remind me to (.+?)(?: in (.+))?$",
            ],
            "intent": "set_reminder",
            "extract": lambda m: {
                "delay": _parse_duration((m.group(1) or "").strip()) if m.lastindex and m.lastindex >= 1 else None,
                "task": (m.group(2) or m.group(1) or "").strip(),
            },
        })

        # --- Timer ---
        C.append({
            "patterns": [
                r"set (?:a )?timer (?:for )?(.+)",
                r"timer (?:for )?(.+)",
                r"start (?:a )?timer (?:for )?(.+)",
            ],
            "intent": "set_timer",
            "extract": lambda m: {"duration": _parse_duration(m.group(1).strip())},
        })

        # --- Open app ---
        C.append({
            "patterns": [
                r"open (.+?)$",
                r"launch (.+?)$",
                r"start (?:the )?(.+?) app$",
            ],
            "intent": "open_app",
            "extract": lambda m: {"app": m.group(1).strip()},
        })

        # --- Web search ---
        C.append({
            "patterns": [
                r"search (?:for )?(.+)",
                r"google (.+)",
                r"look up (.+)",
                r"find (.+?) online",
            ],
            "intent": "web_search",
            "extract": lambda m: {"query": m.group(1).strip()},
        })

        # --- Notes ---
        C.append({
            "patterns": [r"(?:make a )?note:? (.+)", r"remember (?:that )?(.+)", r"write down (.+)"],
            "intent": "add_note",
            "extract": lambda m: {"text": m.group(1).strip()},
        })

        C.append({
            "patterns": [r"read (?:my )?notes", r"show (?:my )?notes", r"list (?:my )?notes"],
            "intent": "read_notes",
        })

        C.append({
            "patterns": [r"clear (?:my )?notes", r"delete (?:my )?notes"],
            "intent": "clear_notes",
        })

        # --- To-do ---
        C.append({
            "patterns": [r"add (?:to )?(?:my )?todo:?\s*(.+)", r"todo:? (.+)", r"add task (.+)"],
            "intent": "add_todo",
            "extract": lambda m: {"task": m.group(1).strip()},
        })

        C.append({
            "patterns": [r"show (?:my )?todo", r"list (?:my )?todo", r"what'?s on my todo"],
            "intent": "list_todo",
        })

        # --- Flashlight ---
        C.append({
            "patterns": [r"turn (on|off) (?:the )?flashlight", r"flashlight (on|off)",
                         r"(enable|disable) torch"],
            "intent": "toggle_flashlight",
            "extract": lambda m: {"on": m.group(1) in ("on", "enable")},
        })

        # --- WiFi ---
        C.append({
            "patterns": [r"turn (on|off) wifi", r"wifi (on|off)"],
            "intent": "toggle_wifi",
            "extract": lambda m: {"on": m.group(1) == "on"},
        })

        # --- Bluetooth ---
        C.append({
            "patterns": [r"turn (on|off) bluetooth", r"bluetooth (on|off)"],
            "intent": "toggle_bluetooth",
            "extract": lambda m: {"on": m.group(1) == "on"},
        })

        # --- Volume ---
        C.append({
            "patterns": [r"(mute|unmute)(?: (?:the )?(?:phone|sound|audio))?",
                         r"turn (?:the )?(?:sound|volume) (on|off)"],
            "intent": "set_volume",
            "extract": lambda m: {"mute": "mute" in m.group(0) or m.group(0).endswith("off")},
        })

        C.append({
            "patterns": [r"volume (?:up|down|to \d+)",
                         r"(increase|decrease|raise|lower) (?:the )?volume"],
            "intent": "adjust_volume",
        })

        # --- Camera ---
        C.append({
            "patterns": [r"(?:open|launch|start) (?:the )?camera", r"take (?:a )?photo"],
            "intent": "open_camera",
        })

        C.append({
            "patterns": [r"take (?:a )?screenshot", r"screenshot"],
            "intent": "screenshot",
        })

        # --- Joke / Fact ---
        C.append({
            "patterns": [r"tell (?:me )?a joke", r"joke"],
            "intent": "joke",
        })

        C.append({
            "patterns": [r"tell (?:me )?(?:a |an )?(?:random )?fact", r"fun fact"],
            "intent": "fact",
        })

        # --- Help / Stop / Goodbye ---
        C.append({
            "patterns": [r"\bhelp\b", r"what can you do", r"commands"],
            "intent": "help",
        })

        C.append({
            "patterns": [r"\b(quit|exit|stop|bye|goodbye)\b", r"shut down"],
            "intent": "exit",
        })

        # --- Thank you ---
        C.append({
            "patterns": [r"thank(s| you)", r"appreciate it"],
            "intent": "thanks",
            "reply": "Anytime!",
        })


# ---- helpers ----
def random_greeting() -> str:
    import random
    return random.choice([
        "Hey! What's up?",
        "Hi there!",
        "Hello! How can I help?",
        "Hey, ready when you are.",
        "Yo! What's on your mind?",
    ])


def _parse_time(s: str) -> str:
    """Parse a free-form time like '7am', '7:30 pm', '19:00', '7 in the morning' -> 'HH:MM' 24h."""
    s = s.lower().replace(".", "").strip()
    s = s.replace("in the morning", "am").replace("in the evening", "pm").replace("at night", "pm")
    s = s.replace("o'clock", "").strip()
    # 7am / 7 am
    m = re.search(r"(\d{1,2})(?::(\d{2}))?\s*(am|pm)?", s)
    if not m:
        return s
    h, mn, mer = int(m.group(1)), int(m.group(2) or 0), m.group(3)
    if mer == "pm" and h < 12: h += 12
    if mer == "am" and h == 12: h = 0
    return f"{h:02d}:{mn:02d}"


def _parse_duration(s: str) -> int:
    """Parse '10 minutes', '2 hours', '1 hour 30 minutes' -> seconds."""
    s = s.lower()
    total = 0
    for n, unit in re.findall(r"(\d+)\s*(second|minute|hour|sec|min|hr)s?", s):
        n = int(n)
        if unit.startswith("sec"): total += n
        elif unit.startswith("min"): total += n * 60
        elif unit.startswith("hr") or unit == "hour": total += n * 3600
    if total == 0:
        # fallback: bare number = minutes
        m = re.search(r"\d+", s)
        if m: total = int(m.group(0)) * 60
    return total


if __name__ == "__main__":
    b = Brain()
    tests = [
        "hey mavis set alarm for 7am",
        "call mom",
        "what is 25 times 17",
        "remind me in 10 minutes to drink water",
        "open youtube",
        "search for python tutorials",
        "tell me a joke",
        "what's the time",
        "send text to John: running late",
    ]
    for t in tests:
        print(f"IN : {t}")
        print(f"OUT: {b.parse(t)}\n")

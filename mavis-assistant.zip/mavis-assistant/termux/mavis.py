#!/usr/bin/env python3
"""
Mavis — Termux voice assistant.
Run on your Android phone inside Termux + Termux:API.

Setup: see ../README.md (Option B)
Run:   python mavis.py
"""

import os
import sys
import json
import queue
import time
import threading
import subprocess
from datetime import datetime
from pathlib import Path

# ---- graceful import handling ----
try:
    from brain import Brain
except ImportError:
    sys.path.insert(0, os.path.dirname(__file__))
    from brain import Brain  # type: ignore

# Vosk for offline STT
try:
    from vosk import Model, KaldiRecognizer
    import sounddevice as sd
    VOSK_OK = True
except Exception as e:
    VOSK_OK = False
    print(f"[warn] Vosk not installed: {e}")


# ---- config ----
VOSK_MODEL_PATH = os.path.expanduser("~/vosk-model")
SAMPLE_RATE = 16000
NOTES_FILE = os.path.expanduser("~/.mavis/notes.txt")
TODO_FILE = os.path.expanduser("~/.mavis/todo.txt")
CONTACTS_FILE = os.path.expanduser("~/.mavis/contacts.json")
WAKE_WORDS = {"mavis", "hey mavis", "okay mavis", "ok mavis", "assistant"}


# ---- TTS via Termux ----
def speak(text: str):
    if not text:
        return
    print(f"Mavis: {text}")
    try:
        subprocess.run(["termux-tts-speak", text], check=False, timeout=30)
    except FileNotFoundError:
        print("[hint] Install Termux:API app + `pkg install termux-api` for TTS.")
    except Exception as e:
        print(f"[tts-err] {e}")


# ---- Termux:API helpers ----
def termux_api(cmd: list, timeout=15):
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    except Exception as e:
        print(f"[api-err] {e}")
        return None


def battery_level() -> int:
    r = termux_api(["termux-battery-status"])
    if r and r.returncode == 0:
        try:
            return int(json.loads(r.stdout).get("percentage", -1))
        except Exception:
            pass
    return -1


def make_call(name_or_number: str) -> str:
    # Try contact lookup first
    number = _resolve_contact(name_or_number) or name_or_number
    r = termux_api(["termux-telephony-call", number])
    return f"Calling {number}." if r and r.returncode == 0 else f"Couldn't call {number}."


def send_sms(name_or_number: str, message: str) -> str:
    number = _resolve_contact(name_or_number) or name_or_number
    r = termux_api(["termux-sms-send", "-n", number, message])
    return f"Sent text to {number}." if r and r.returncode == 0 else f"Couldn't text {number}."


def send_whatsapp(name_or_number: str, message: str) -> str:
    number = _resolve_contact(name_or_number) or name_or_number
    # Strip non-digits, ensure country code
    digits = "".join(c for c in number if c.isdigit() or c == "+")
    r = termux_api(["termux-open", f"https://wa.me/{digits.lstrip('+')}?text={message}"])
    return f"Opening WhatsApp for {number}." if r and r.returncode == 0 else f"Couldn't open WhatsApp."


def set_alarm(time_str: str) -> str:
    try:
        h, m = time_str.split(":")
        h, m = int(h), int(m)
        # Termux doesn't have direct alarm API, but we can use termux-job-scheduler or open clock app
        r = termux_api(["termux-alarm", "-t", time_str])
        if r and r.returncode == 0:
            return f"Alarm set for {time_str}."
    except Exception:
        pass
    return f"Couldn't set alarm for {time_str}."


def set_reminder(delay_seconds: int, task: str) -> str:
    if not delay_seconds or delay_seconds <= 0:
        return "I need a time. Try 'remind me in 5 minutes to stretch'."
    def _fire():
        time.sleep(delay_seconds)
        speak(f"Reminder: {task}")
    threading.Thread(target=_fire, daemon=True).start()
    return f"Got it. I'll remind you to {task} in {_humanize_seconds(delay_seconds)}."


def set_timer(duration_seconds: int) -> str:
    if not duration_seconds or duration_seconds <= 0:
        return "How long? Try 'set timer for 5 minutes'."
    def _fire():
        time.sleep(duration_seconds)
        # termux-notification + tts
        termux_api(["termux-notification", "-t", "Timer done", "-c", "Your timer is up!"])
        speak("Timer is up!")
    threading.Thread(target=_fire, daemon=True).start()
    return f"Timer started for {_humanize_seconds(duration_seconds)}."


def open_app(app: str) -> str:
    app = app.strip().lower()
    # common aliases
    aliases = {
        "youtube": "com.google.android.youtube",
        "chrome": "com.android.chrome",
        "gmail": "com.google.android.gm",
        "maps": "com.google.android.apps.maps",
        "settings": "com.android.settings",
        "camera": "com.android.camera",
        "calculator": "com.android.calculator2",
        "calendar": "com.google.android.calendar",
        "photos": "com.google.android.apps.photos",
        "play store": "com.android.vending",
        "messages": "com.google.android.apps.messaging",
        "phone": "com.android.dialer",
        "contacts": "com.android.contacts",
        "clock": "com.google.android.deskclock",
        "spotify": "com.spotify.music",
        "instagram": "com.instagram.android",
        "facebook": "com.facebook.katana",
        "twitter": "com.twitter.android",
        "x": "com.twitter.android",
        "telegram": "org.telegram.messenger",
        "whatsapp": "com.whatsapp",
        "files": "com.android.documentsui",
        "notes": "com.google.android.keep",
    }
    pkg = aliases.get(app, app)
    # try monkey first (works on most)
    r = termux_api(["termux-open", f"intent://#Intent;package={pkg};end"])
    if r and r.returncode != 0:
        # fallback: just try to launch by package name via am
        r2 = termux_api(["am", "start", "-a", "android.intent.action.MAIN",
                        "-n", f"{pkg}/.MainActivity"])
    return f"Opening {app}."


def web_search(query: str) -> str:
    from urllib.parse import quote
    url = f"https://www.google.com/search?q={quote(query)}"
    termux_api(["termux-open", url])
    return f"Searching the web for {query}."


def toggle_flashlight(on: bool) -> str:
    """Toggle flashlight via termux-api (if supported) or torch app."""
    r = termux_api(["termux-torch", "on" if on else "off"])
    if r and r.returncode == 0:
        return f"Flashlight {'on' if on else 'off'}."
    return "Couldn't toggle flashlight."


def toggle_wifi(on: bool) -> str:
    r = termux_api(["termux-wifi-enable", "true" if on else "false"])
    return f"WiFi {'on' if on else 'off'}." if r and r.returncode == 0 else "Couldn't toggle WiFi."


def toggle_bluetooth(on: bool) -> str:
    r = termux_api(["termux-bluetooth-enable", "true" if on else "false"])
    return f"Bluetooth {'on' if on else 'off'}." if r and r.returncode == 0 else "Couldn't toggle Bluetooth."


def adjust_volume(action: str) -> str:
    direction = "up" if "up" in action or "raise" in action or "increase" in action else "down"
    # media volume keys
    key = "24" if direction == "up" else "25"
    for _ in range(3):
        termux_api(["input", "keyevent", key])
    return f"Volume {direction}."


def set_volume(mute: bool) -> str:
    # ringer mode
    mode = "silent" if mute else "normal"
    r = termux_api(["termux-volume", mode])
    return f"Phone {'muted' if mute else 'unmuted'}." if r and r.returncode == 0 else f"Tried to set {mode}."


def open_camera() -> str:
    termux_api(["am", "start", "-a", "android.media.action.IMAGE_CAPTURE"])
    return "Opening camera."


def screenshot() -> str:
    out = os.path.expanduser("~/storage/pictures/screenshot.png")
    r = termux_api(["screencap", "-p", out])
    return f"Screenshot saved to {out}." if r and r.returncode == 0 else "Couldn't take screenshot."


# ---- Notes / To-do ----
def _ensure_storage():
    os.makedirs(os.path.dirname(NOTES_FILE), exist_ok=True)


def add_note(text: str) -> str:
    _ensure_storage()
    with open(NOTES_FILE, "a") as f:
        f.write(f"[{datetime.now():%Y-%m-%d %H:%M}] {text}\n")
    return "Noted."


def read_notes() -> str:
    if not os.path.exists(NOTES_FILE):
        return "No notes yet."
    with open(NOTES_FILE) as f:
        notes = f.read().strip().splitlines()
    if not notes:
        return "No notes yet."
    # speak last 3
    last = notes[-3:]
    return "Your last notes: " + " ... ".join(last)


def clear_notes() -> str:
    if os.path.exists(NOTES_FILE):
        os.remove(NOTES_FILE)
    return "Notes cleared."


def add_todo(task: str) -> str:
    _ensure_storage()
    with open(TODO_FILE, "a") as f:
        f.write(f"- {task}\n")
    return f"Added: {task}."


def list_todo() -> str:
    if not os.path.exists(TODO_FILE):
        return "Your to-do list is empty."
    with open(TODO_FILE) as f:
        items = [l.strip() for l in f if l.strip()]
    if not items:
        return "Your to-do list is empty."
    return "You have " + "; ".join(items[:5])


# ---- Jokes / facts (built-in) ----
import random

JOKES = [
    "Why don't scientists trust atoms? Because they make up everything.",
    "I told my computer I needed a break, and it said 'no problem, I'll go to sleep.'",
    "Why did the developer go broke? Because he used up all his cache.",
    "There are 10 kinds of people in the world: those who understand binary, and those who don't.",
    "Why do programmers prefer dark mode? Because light attracts bugs.",
]

FACTS = [
    "Honey never spoils. Archaeologists have found 3000-year-old honey in Egyptian tombs that's still edible.",
    "A group of flamingos is called a 'flamboyance'.",
    "Bananas are berries, but strawberries aren't.",
    "Octopuses have three hearts and blue blood.",
    "The Eiffel Tower can grow up to 6 inches taller in summer due to thermal expansion.",
]


# ---- Contacts ----
def _resolve_contact(name: str) -> str | None:
    if not os.path.exists(CONTACTS_FILE):
        return None
    try:
        with open(CONTACTS_FILE) as f:
            contacts = json.load(f)
        n = name.lower().strip()
        return contacts.get(n)
    except Exception:
        return None


# ---- Math ----
def safe_calc(expr: str) -> str:
    import ast, operator as op
    ops = {ast.Add: op.add, ast.Sub: op.sub, ast.Mult: op.mul, ast.Div: op.truediv, ast.Pow: op.pow, ast.Mod: op.mod, ast.USub: op.neg}
    def _eval(node):
        if isinstance(node, ast.Num): return node.n
        if isinstance(node, ast.BinOp): return ops[type(node.op)](_eval(node.left), _eval(node.right))
        if isinstance(node, ast.UnaryOp): return ops[type(node.op)](_eval(node.operand))
        raise ValueError("bad expr")
    # word-to-symbol
    s = expr.lower()
    s = s.replace("plus", "+").replace("minus", "-").replace("times", "*").replace("multiplied by", "*")
    s = s.replace("divided by", "/").replace("x", "*")
    # strip "what is" / "calculate" / "compute"
    for kw in ["what is", "what's", "calculate", "compute"]:
        s = s.replace(kw, "")
    s = s.strip()
    try:
        return str(_eval(ast.parse(s, mode="eval").body))
    except Exception as e:
        return f"I couldn't compute that: {e}"


# ---- Intent dispatch ----
def handle(intent) -> str:
    name = intent.name
    p = intent.params

    if name == "greet":
        return intent.reply or "Hello!"
    if name == "smalltalk_how_are_you":
        return intent.reply
    if name == "get_time":
        return f"It's {datetime.now():%I:%M %p}."
    if name == "get_date":
        return f"Today is {datetime.now():%A, %B %d, %Y}."
    if name == "get_battery":
        b = battery_level()
        return f"Battery is at {b}%." if b >= 0 else "I can't read the battery right now."
    if name == "calc":
        return f"That's {safe_calc(p.get('expr', ''))}."
    if name == "call_contact":
        return make_call(p.get("name", ""))
    if name == "send_sms":
        return send_sms(p.get("name", ""), p.get("message", ""))
    if name == "send_whatsapp":
        return send_whatsapp(p.get("name", ""), p.get("message", ""))
    if name == "set_alarm":
        return set_alarm(p.get("time", ""))
    if name == "set_reminder":
        return set_reminder(int(p.get("delay") or 0), p.get("task", ""))
    if name == "set_timer":
        return set_timer(int(p.get("duration") or 0))
    if name == "open_app":
        return open_app(p.get("app", ""))
    if name == "web_search":
        return web_search(p.get("query", ""))
    if name == "add_note":
        return add_note(p.get("text", ""))
    if name == "read_notes":
        return read_notes()
    if name == "clear_notes":
        return clear_notes()
    if name == "add_todo":
        return add_todo(p.get("task", ""))
    if name == "list_todo":
        return list_todo()
    if name == "toggle_flashlight":
        return toggle_flashlight(bool(p.get("on")))
    if name == "toggle_wifi":
        return toggle_wifi(bool(p.get("on")))
    if name == "toggle_bluetooth":
        return toggle_bluetooth(bool(p.get("on")))
    if name == "set_volume":
        return set_volume(bool(p.get("mute")))
    if name == "adjust_volume":
        return adjust_volume("up")
    if name == "open_camera":
        return open_camera()
    if name == "screenshot":
        return screenshot()
    if name == "joke":
        return random.choice(JOKES)
    if name == "fact":
        return random.choice(FACTS)
    if name == "help":
        return ("I can: make calls, send texts, open apps, set alarms, set reminders, "
                "set timers, take notes, manage your to-do, search the web, "
                "tell jokes, take screenshots, toggle flashlight/WiFi/Bluetooth, "
                "tell you the time, date, and battery. Say 'goodbye' to quit.")
    if name == "thanks":
        return intent.reply
    if name == "exit":
        return "__EXIT__"
    return intent.reply or "I didn't quite get that."


def _humanize_seconds(s: int) -> str:
    if s < 60: return f"{s} seconds"
    if s < 3600: return f"{s // 60} minutes"
    h, m = divmod(s // 60, 60)
    return f"{h} hour{'s' if h != 1 else ''} {m} minutes" if m else f"{h} hour{'s' if h != 1 else ''}"


# ---- STT loop ----
def stt_loop(brain: Brain, on_utterance):
    """Continuously listen, run wake-word detection, return full utterances to callback."""
    if not VOSK_OK:
        print("[error] Install vosk + sounddevice: pip install vosk sounddevice")
        return
    if not os.path.isdir(VOSK_MODEL_PATH):
        print(f"[error] Vosk model not found at {VOSK_MODEL_PATH}")
        print("Download: curl -L -o ~/vosk-model.zip https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip")
        print("         unzip ~/vosk-model.zip -d ~ && mv ~/vosk-model-small-en-us-0.15 ~/vosk-model")
        return

    model = Model(VOSK_MODEL_PATH)
    rec = KaldiRecognizer(model, SAMPLE_RATE)
    rec.SetWords(True)
    q = queue.Queue()

    def callback(indata, frames, time_info, status):
        if status:
            print(status, file=sys.stderr)
        q.put(bytes(indata))

    listening = False  # whether we've heard the wake word
    print("[mavis] Listening for wake word 'mavis'... (Ctrl+C to stop)")
    try:
        with sd.RawInputStream(samplerate=SAMPLE_RATE, blocksize=8000, dtype="int16",
                               channels=1, callback=callback):
            while True:
                data = q.get()
                if rec.AcceptWaveform(data):
                    res = json.loads(rec.Result())
                    text = (res.get("text") or "").strip().lower()
                    if not text:
                        continue
                    if not listening:
                        if any(w in text for w in WAKE_WORDS):
                            listening = True
                            speak("Yes?")
                            print("[wake] heard wake word, awaiting command...")
                    else:
                        listening = False
                        print(f"[heard] {text}")
                        on_utterance(text)
    except KeyboardInterrupt:
        print("\n[mavis] bye.")
    except Exception as e:
        print(f"[mavis] audio error: {e}")


# ---- Text-mode REPL (for testing without mic) ----
def repl(brain: Brain):
    speak("Mavis online. Type a command, or 'goodbye' to quit.")
    while True:
        try:
            text = input("you> ").strip()
        except (EOFError, KeyboardInterrupt):
            break
        if not text:
            continue
        intent = brain.parse(text)
        reply = handle(intent)
        if reply == "__EXIT__":
            speak("Goodbye.")
            break
        speak(reply)


# ---- main ----
def main():
    brain = Brain()
    if "--text" in sys.argv:
        repl(brain)
    else:
        def on_utt(text):
            intent = brain.parse(text)
            reply = handle(intent)
            if reply == "__EXIT__":
                speak("Goodbye.")
                sys.exit(0)
            speak(reply)
        stt_loop(brain, on_utt)


if __name__ == "__main__":
    main()

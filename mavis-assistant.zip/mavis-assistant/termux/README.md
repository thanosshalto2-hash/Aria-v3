# Mavis for Phone (Termux) — Quick Start

> **No APK, no Play Store, no cloud. Just Termux + Termux:API. Fully offline.**

## 1. Install Termux

⚠️ **Get it from F-Droid, NOT the Play Store.** Play Store version is outdated and won't work.

- Download: https://f-droid.org/en/packages/com.termux/
- Or: https://f-droid.org/en/packages/com.termux.api/  ← you need BOTH apps

## 2. Grant Termux permissions

Phone settings → Apps → Termux → Permissions:
- Microphone ✅
- Storage ✅
- Contacts ✅
- Phone ✅
- SMS ✅

Then open **Termux:API** app once and accept all permission prompts.

## 3. Run installer

Open Termux, paste:

```bash
pkg update -y && pkg upgrade -y
pkg install python termux-api git curl unzip -y
pip install vosk sounddevice
cd ~
curl -L -o vosk-model.zip https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip
unzip -q vosk-model.zip && mv vosk-model-small-en-us-0.15 vosk-model && rm vosk-model.zip
termux-setup-storage
```

## 4. Get Mavis

If you have this folder already on your phone (via git clone, file transfer, etc.):

```bash
cd ~/mavis-assistant/termux
python mavis.py
```

If you don't have it yet, copy the `mavis.py`, `brain.py`, etc. files into a folder on your phone. Easiest: use `termux-setup-storage`, then put the files in `~/storage/downloads/mavis/`, then `cd` there in Termux.

## 5. Try it

```bash
# Voice mode (speak after "hey mavis")
python mavis.py

# Text mode (no mic needed, great for testing)
python mavis.py --text
```

---

## Voice commands cheat sheet

| Say this... | Does this |
|---|---|
| `hey mavis what is the time` | Tells time |
| `hey mavis what's the date` | Tells date |
| `hey mavis battery` | Battery % |
| `hey mavis set alarm for 7am` | Sets alarm |
| `hey mavis set timer for 5 minutes` | Starts timer |
| `hey mavis remind me in 10 minutes to stretch` | Reminder |
| `hey mavis call mom` | Calls contact |
| `hey mavis text John: running late` | Sends SMS |
| `hey mavis whatsapp hello to Sarah` | Opens WhatsApp with prefilled msg |
| `hey mavis open youtube` | Opens app |
| `hey mavis search for python tutorials` | Web search |
| `hey mavis note: meeting at 3pm` | Saves a note |
| `hey mavis read my notes` | Reads recent notes |
| `hey mavis add todo: buy milk` | Adds to-do |
| `hey mavis show my todo` | Lists to-do |
| `hey mavis turn on flashlight` | Torch on/off |
| `hey mavis turn on wifi` | WiFi on/off |
| `hey mavis take a screenshot` | Saves screenshot |
| `hey mavis tell me a joke` | Tells joke |
| `hey mavis what is 25 times 17` | Calculator |
| `hey mavis help` | Lists commands |
| `hey mavis goodbye` | Exits |

---

## Customizing contacts

Edit `~/.mavis/contacts.json`:

```json
{
  "mom":   "+15551234567",
  "dad":   "+15559876543",
  "john":  "+15551112222",
  "office":"+15554443333"
}
```

Then "hey mavis call mom" will dial your mom's real number.

---

## Adding your own commands

Edit `brain.py` and add to the `_register_defaults` method:

```python
C.append({
    "patterns": [r"play (.+) on spotify"],
    "intent": "play_spotify",
    "extract": lambda m: {"song": m.group(1).strip()},
})
```

Then add a handler in `mavis.py`:

```python
elif name == "play_spotify":
    return open_app(f"spotify:search:{p.get('song','')}")
```

Restart Mavis. Done.

---

## Troubleshooting

**"Vosk model not found"** — Make sure `~/vosk-model` exists. If you named it differently, edit `VOSK_MODEL_PATH` in `mavis.py`.

**No sound on text-to-speech** — Make sure Termux:API app is installed and you opened it once to accept permissions.

**"Couldn't call X"** — Termux doesn't have telephony permission by default. The call API requires a recent Termux:API app build. Alternative: use `termux-telephony-call` if available, or it will open the dialer.

**Microphone doesn't work** — Check Termux app permissions → Microphone. On Android 12+, you may also need to grant "Nearby devices" permission.

**Slow first run** — Vosk model loads into memory (~2 seconds). After that it's instant.

---

## Battery use

Vosk STT running constantly uses ~3-5% battery per hour. To save power, say "goodbye" when you're done — or just don't open the app. The mic only listens while the script is running.

---

## Files in this folder

```
termux/
├── mavis.py          ← main entry point
├── brain.py          ← rule engine (intent recognition)
├── install.sh        ← one-shot installer
├── README.md         ← this file
└── requirements.txt
```

# Mavis Android App

> A real on-device voice assistant APK. No cloud, no API keys, no LLM.

## Build

### Option 1: Android Studio (easiest)

1. Open Android Studio (any version from Hedgehog / 2023.1+)
2. File → Open → select the `android-app/` folder
3. Wait for Gradle sync
4. Build → Build Bundle(s) / APK(s) → Build APK(s)
5. APK lands in `app/build/outputs/apk/debug/app-debug.apk`

### Option 2: Command line

```bash
cd android-app
./gradlew assembleDebug
adb install app/build/outputs/apk/debug/app-debug.apk
```

If you don't have gradlew, run `gradle wrapper` once to generate it.

## Required permissions

When you first launch Mavis, it will ask for:

- 🎤 Microphone (for voice recognition)
- 📞 Phone (for "call mom")
- 💬 SMS (for "text John: ...")
- 👤 Contacts (for contact lookup)
- 📷 Camera (for flashlight + camera)
- 📍 Storage (for notes & screenshots)

If you deny any, the corresponding feature won't work — everything else still will.

## How it works

```
[mic button] → Android SpeechRecognizer (on-device, Google app)
                ↓ text
              Brain.parse() (rule engine, Kotlin)
                ↓ Intent
              Handlers (Call, SMS, Alarm, App, Note, …)
                ↓ action result
              TextToSpeech.speak() (on-device, system)
```

Everything stays on the phone. No network calls. The only permission the OS uses for STT is the microphone + Google app's offline speech model (which Android already has cached locally after first use).

## Customizing contacts

Create a file at `Android/data/com.mavis.assistant/files/contacts.txt`:

```
mom: +15551234567
dad: +15559876543
john: +15551112222
```

(One contact per line, `name: number`.)

Or use a file manager app to navigate there. Path: `/sdcard/Android/data/com.mavis.assistant/files/contacts.txt`

## Adding commands

Edit `Brain.kt`, find `registerDefaults()`, and add:

```kotlin
cmds.add(Cmd(
    listOf("play (.+) on spotify".toRegex()),
    "play_spotify",
    { m -> mapOf("song" to m.groupValues[1].trim()) }
))
```

Then add a handler in `Handlers.kt`:

```kotlin
fun playSpotify(song: String): String {
    val i = Intent(Intent.ACTION_VIEW, Uri.parse("spotify:search:${Uri.encode(song)}"))
    return try { ctx.startActivity(i); "Searching Spotify for $song." }
    catch (e: Exception) { "Spotify isn't installed." }
}
```

And wire it up in `Brain.kt` `handle()`:

```kotlin
"play_spotify" -> handlers.playSpotify(intent.params["song"] ?: "")
```

## Notes & to-do

Stored in app-private storage at:
- `/sdcard/Android/data/com.mavis.assistant/files/notes.txt`
- `/sdcard/Android/data/com.mavis.assistant/files/todo.txt`

Survives reinstalls, cleared on uninstall.

## Limitations

- iOS: not possible. Apple locks down AccessibilityService. (Use the Termux version on Android, or the PC controller for iOS via ADB-over-network tricks — limited.)
- Programmatic WiFi/Bluetooth toggle: requires system-app privileges. We deep-link to settings instead — tap once to confirm.
- Real screenshots: require MediaProjection, which needs an in-app system dialog. We open Photos instead.
- "True" always-on wake word: needs a Vosk integration (see `MavisService.kt` TODO). The current build has a foreground service ready for it; a 5-line Vosk init will give you "Hey Mavis" detection.

## License

MIT.

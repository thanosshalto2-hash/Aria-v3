package com.mavis.assistant.brain

/**
 * Parsed user intent: a name + extracted parameters + a confidence score.
 */
data class Intent(
    val name: String,
    val params: Map<String, String> = emptyMap(),
    val confidence: Double = 1.0,
    val directReply: String? = null,
)

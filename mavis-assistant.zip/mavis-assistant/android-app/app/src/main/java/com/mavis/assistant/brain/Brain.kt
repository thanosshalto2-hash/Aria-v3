package com.mavis.assistant.brain

import android.content.Context
import com.mavis.assistant.brain.handlers.*
import java.util.Calendar

/**
 * Mavis Brain (Kotlin port).
 * Rule-based intent parser + dispatcher. No LLM, no network.
 */
class Brain(private val ctx: Context) {

    private data class Cmd(
        val patterns: List<Regex>,
        val intent: String,
        val extract: (MatchResult) -> Map<String, String> = { emptyMap() },
    )

    private val cmds: MutableList<Cmd> = mutableListOf()
    private val handlers = Handlers(ctx)

    init {
        registerDefaults()
    }

    // ---- public API ----
    fun parse(raw: String): Intent {
        val text = normalize(raw)
        var best: Cmd? = null
        var bestMatch: MatchResult? = null
        var bestScore = 0.0

        for (cmd in cmds) {
            for (pat in cmd.patterns) {
                val m = pat.find(text)
                if (m != null) {
                    val score = m.value.length.toDouble() / text.length.coerceAtLeast(1)
                    if (score > bestScore) {
                        bestScore = score
                        best = cmd
                        bestMatch = m
                    }
                }
            }
        }

        if (best == null || bestMatch == null) {
            return Intent("unknown", mapOf("text" to text), 0.0,
                "Sorry, I didn't catch that. Tap help to see what I can do.")
        }
        val params = best.extract(bestMatch)
        return Intent(best.intent, params, bestScore)
    }

    fun handle(intent: Intent): String {
        return when (intent.name) {
            "greet" -> pick(listOf("Hey! What's up?", "Hi there!", "Hello!", "Hey, ready when you are."))
            "smalltalk_how_are_you" -> "Doing great, thanks for asking. What's on your mind?"
            "get_time" -> {
                val c = Calendar.getInstance()
                "%02d:%02d %s".format(
                    c.get(Calendar.HOUR), c.get(Calendar.MINUTE),
                    if (c.get(Calendar.AM_PM) == Calendar.AM) "AM" else "PM"
                ).let { "It's $it." }
            }
            "get_date" -> {
                val c = Calendar.getInstance()
                val days = arrayOf("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday")
                val months = arrayOf("January","February","March","April","May","June","July","August","September","October","November","December")
                "Today is ${days[c.get(Calendar.DAY_OF_WEEK) - 1]}, ${months[c.get(Calendar.MONTH)]} ${c.get(Calendar.DAY_OF_MONTH)}, ${c.get(Calendar.YEAR)}."
            }
            "get_battery" -> handlers.battery()
            "calc" -> handlers.calc(intent.params["expr"] ?: "")
            "call_contact" -> handlers.call(intent.params["name"] ?: "")
            "send_sms" -> handlers.sms(intent.params["name"] ?: "", intent.params["message"] ?: "")
            "send_whatsapp" -> handlers.whatsapp(intent.params["name"] ?: "", intent.params["message"] ?: "")
            "set_alarm" -> handlers.setAlarm(intent.params["time"] ?: "")
            "set_reminder" -> handlers.setReminder(intent.params["delay"]?.toLongOrNull() ?: 0L, intent.params["task"] ?: "")
            "set_timer" -> handlers.setTimer(intent.params["duration"]?.toLongOrNull() ?: 0L)
            "open_app" -> handlers.openApp(intent.params["app"] ?: "")
            "web_search" -> handlers.webSearch(intent.params["query"] ?: "")
            "add_note" -> handlers.addNote(intent.params["text"] ?: "")
            "read_notes" -> handlers.readNotes()
            "clear_notes" -> handlers.clearNotes()
            "add_todo" -> handlers.addTodo(intent.params["task"] ?: "")
            "list_todo" -> handlers.listTodo()
            "toggle_flashlight" -> handlers.toggleFlashlight(intent.params["on"] == "true")
            "toggle_wifi" -> handlers.toggleWifi(intent.params["on"] == "true")
            "toggle_bluetooth" -> handlers.toggleBluetooth(intent.params["on"] == "true")
            "set_volume" -> handlers.setVolume(intent.params["mute"] == "true")
            "adjust_volume" -> handlers.adjustVolume("up")
            "open_camera" -> handlers.openCamera()
            "screenshot" -> handlers.screenshot()
            "joke" -> pick(JOKES)
            "fact" -> pick(FACTS)
            "help" -> helpText()
            "thanks" -> "Anytime!"
            "exit" -> "__EXIT__"
            "unknown" -> intent.directReply ?: "I didn't quite get that."
            else -> intent.directReply ?: "I didn't quite get that."
        }
    }

    fun helpText(): String =
        "I can: make calls, send texts, open apps, set alarms, " +
        "set reminders and timers, take notes, manage your to-do, " +
        "search the web, take screenshots, toggle flashlight/WiFi/Bluetooth, " +
        "and tell you the time, date, battery, jokes, and facts. " +
        "Say 'goodbye' to quit."

    // ---- internals ----
    private fun normalize(text: String): String {
        var t = text.lowercase().trim()
        for (w in listOf("hey mavis", "okay mavis", "ok mavis", "mavis", "hey assistant")) {
            t = t.replace(w, "").trim()
        }
        return t
    }

    private fun pick(list: List<String>): String = list.random()

    private fun registerDefaults() {
        val c = cmds

        c.add(Cmd(listOf("\\b(hi|hello|hey|yo|howdy|hola)\\b".toRegex()), "greet"))
        c.add(Cmd(listOf("how (are|r) you".toRegex(), "how('?s| is) it going".toRegex(), "what's up".toRegex()), "smalltalk_how_are_you"))
        c.add(Cmd(listOf("what(?:'s| is) the time".toRegex(), "tell me the time".toRegex(), "current time".toRegex(), "what time is it".toRegex()), "get_time"))
        c.add(Cmd(listOf("what(?:'s| is|s| are)? (the )?date".toRegex(), "what day is (it|today)".toRegex(), "today(?:'s|s)? date".toRegex()), "get_date"))
        c.add(Cmd(listOf("battery (level|status|how much)".toRegex(), "how much battery".toRegex()), "get_battery"))

        c.add(Cmd(
            listOf("what(?:'s| is) (.+?)\\s+(plus|minus|times|divided by|multiplied by|x|\\+|-|\\*|/)\\s+(.+)".toRegex(),
                   "calculate (.+)".toRegex(), "compute (.+)".toRegex()),
            "calc",
            { m -> mapOf("expr" to m.value) }
        ))

        c.add(Cmd(
            listOf("call (\\w[\\w\\s]*?)(?:\\s+on (?:their )?(?:mobile|cell|phone))?$".toRegex(),
                   "make a call to (\\w[\\w\\s]*)".toRegex(), "phone (\\w[\\w\\s]*)".toRegex(), "dial (\\w[\\w\\s]*)".toRegex()),
            "call_contact",
            { m -> mapOf("name" to m.groupValues[1].trim()) }
        ))

        c.add(Cmd(
            listOf("send (?:a )?(?:text|sms|message) to (\\w[\\w\\s]*?): (.+)".toRegex(),
                   "text (\\w[\\w\\s]*?): (.+)".toRegex(),
                   "message (\\w[\\w\\s]*?): (.+)".toRegex()),
            "send_sms",
            { m -> mapOf("name" to m.groupValues[1].trim(), "message" to m.groupValues[2].trim()) }
        ))

        c.add(Cmd(
            listOf("whatsapp (.+?) to (\\w[\\w\\s]*)".toRegex(),
                   "send whatsapp to (\\w[\\w\\s]*?): (.+)".toRegex(),
                   "message (\\w[\\w\\s]*?) on whatsapp: (.+)".toRegex()),
            "send_whatsapp",
            { m -> mapOf("name" to m.groupValues[2].trim(), "message" to m.groupValues[1].trim()) }
        ))

        c.add(Cmd(
            listOf("set (?:an? )?alarm (?:for )?(.+)".toRegex(),
                   "wake me up at (.+)".toRegex(),
                   "alarm (?:at )?(.+)".toRegex()),
            "set_alarm",
            { m -> mapOf("time" to parseTime(m.groupValues[1].trim())) }
        ))

        c.add(Cmd(
            listOf("remind me (?:in|after) (.+?) to (.+)".toRegex(),
                   "set (?:a )?reminder (?:for )?(.+?) to (.+)".toRegex()),
            "set_reminder",
            { m -> mapOf("delay" to parseDuration(m.groupValues[1].trim()).toString(),
                        "task" to m.groupValues[2].trim()) }
        ))

        c.add(Cmd(
            listOf("set (?:a )?timer (?:for )?(.+)".toRegex(),
                   "timer (?:for )?(.+)".toRegex()),
            "set_timer",
            { m -> mapOf("duration" to parseDuration(m.groupValues[1].trim()).toString()) }
        ))

        c.add(Cmd(
            listOf("open (.+?)$".toRegex(), "launch (.+?)$".toRegex(), "start (?:the )?(.+?) app$".toRegex()),
            "open_app",
            { m -> mapOf("app" to m.groupValues[1].trim()) }
        ))

        c.add(Cmd(
            listOf("search (?:for )?(.+)".toRegex(), "google (.+)".toRegex(), "look up (.+)".toRegex()),
            "web_search",
            { m -> mapOf("query" to m.groupValues[1].trim()) }
        ))

        c.add(Cmd(listOf("(?:make a )?note:? (.+)".toRegex(), "remember (?:that )?(.+)".toRegex()), "add_note",
            { m -> mapOf("text" to m.groupValues[1].trim()) }))
        c.add(Cmd(listOf("read (?:my )?notes".toRegex(), "show (?:my )?notes".toRegex()), "read_notes"))
        c.add(Cmd(listOf("clear (?:my )?notes".toRegex()), "clear_notes"))

        c.add(Cmd(listOf("add (?:to )?(?:my )?todo:?\\s*(.+)".toRegex(), "todo:? (.+)".toRegex()), "add_todo",
            { m -> mapOf("task" to m.groupValues[1].trim()) }))
        c.add(Cmd(listOf("show (?:my )?todo".toRegex(), "list (?:my )?todo".toRegex()), "list_todo"))

        c.add(Cmd(listOf("turn (on|off) (?:the )?flashlight".toRegex(), "flashlight (on|off)".toRegex()),
            "toggle_flashlight",
            { m -> mapOf("on" to (m.groupValues[1] in listOf("on", "enable")).toString()) }))
        c.add(Cmd(listOf("turn (on|off) wifi".toRegex(), "wifi (on|off)".toRegex()),
            "toggle_wifi",
            { m -> mapOf("on" to (m.groupValues[1] == "on").toString()) }))
        c.add(Cmd(listOf("turn (on|off) bluetooth".toRegex(), "bluetooth (on|off)".toRegex()),
            "toggle_bluetooth",
            { m -> mapOf("on" to (m.groupValues[1] == "on").toString()) }))

        c.add(Cmd(listOf("volume (?:up|down|to \\d+)".toRegex()), "adjust_volume"))
        c.add(Cmd(listOf("(?:open|launch|start) (?:the )?camera".toRegex(), "take (?:a )?photo".toRegex()), "open_camera"))
        c.add(Cmd(listOf("take (?:a )?screenshot".toRegex(), "screenshot".toRegex()), "screenshot"))
        c.add(Cmd(listOf("tell (?:me )?a joke".toRegex(), "joke".toRegex()), "joke"))
        c.add(Cmd(listOf("tell (?:me )?(?:a |an )?(?:random )?fact".toRegex(), "fun fact".toRegex()), "fact"))
        c.add(Cmd(listOf("\\bhelp\\b".toRegex(), "what can you do".toRegex()), "help"))
        c.add(Cmd(listOf("\\b(quit|exit|stop|bye|goodbye)\\b".toRegex()), "exit"))
        c.add(Cmd(listOf("thank(s| you)".toRegex()), "thanks"))
    }

    // ---- helpers ----
    private fun parseTime(s: String): String {
        var t = s.lowercase().replace(".", "").trim()
            .replace("in the morning", "am").replace("in the evening", "pm").replace("at night", "pm")
            .replace("o'clock", "").trim()
        val m = Regex("(\\d{1,2})(?::(\\d{2}))?\\s*(am|pm)?").find(t) ?: return s
        var h = m.groupValues[1].toInt()
        val mn = m.groupValues[2].ifEmpty { "0" }.toInt()
        val mer = m.groupValues[3]
        if (mer == "pm" && h < 12) h += 12
        if (mer == "am" && h == 12) h = 0
        return "%02d:%02d".format(h, mn)
    }

    private fun parseDuration(s: String): Long {
        val re = Regex("(\\d+)\\s*(second|minute|hour|sec|min|hr)s?")
        var total = 0L
        for (m in re.findAll(s.lowercase())) {
            val n = m.groupValues[1].toLong()
            when {
                m.groupValues[2].startsWith("sec") -> total += n
                m.groupValues[2].startsWith("min") -> total += n * 60
                else -> total += n * 3600
            }
        }
        if (total == 0L) {
            val m = Regex("\\d+").find(s)
            if (m != null) total = m.value.toLong() * 60
        }
        return total
    }

    companion object {
        val JOKES = listOf(
            "Why don't scientists trust atoms? Because they make up everything.",
            "I told my computer I needed a break, and it said 'no problem, I'll go to sleep.'",
            "Why did the developer go broke? Because he used up all his cache.",
            "There are 10 kinds of people in the world: those who understand binary, and those who don't.",
            "Why do programmers prefer dark mode? Because light attracts bugs.",
        )
        val FACTS = listOf(
            "Honey never spoils. Archaeologists have found 3000-year-old honey in Egyptian tombs that's still edible.",
            "A group of flamingos is called a 'flamboyance'.",
            "Bananas are berries, but strawberries aren't.",
            "Octopuses have three hearts and blue blood.",
            "The Eiffel Tower can grow up to 6 inches taller in summer due to thermal expansion.",
        )
    }
}

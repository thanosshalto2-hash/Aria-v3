package com.mavis.assistant

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.mavis.assistant.brain.Brain
import com.mavis.assistant.brain.Intent
import java.util.*

/**
 * Mavis — Voice Assistant main activity.
 * Single screen, large mic button, transcript + reply below.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var brain: Brain
    private lateinit var tts: TextToSpeech
    private var recognizer: SpeechRecognizer? = null

    private lateinit var statusText: TextView
    private lateinit var youText: TextView
    private lateinit var mavisText: TextView
    private lateinit var micButton: Button
    private lateinit var helpButton: Button
    private lateinit var logView: ScrollView
    private lateinit var logText: TextView

    private val PERM_REQUEST = 1001
    private val REQUIRED_PERMS = arrayOf(
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.CALL_PHONE,
        Manifest.permission.SEND_SMS,
        Manifest.permission.READ_CONTACTS,
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        brain = Brain(this)
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts.language = Locale.US
            }
        }

        statusText = findViewById(R.id.status_text)
        youText = findViewById(R.id.you_text)
        mavisText = findViewById(R.id.mavis_text)
        micButton = findViewById(R.id.mic_button)
        helpButton = findViewById(R.id.help_button)
        logView = findViewById(R.id.log_scroll)
        logText = findViewById(R.id.log_text)

        micButton.setOnClickListener { onMicTapped() }
        helpButton.setOnClickListener { showHelp() }

        if (!hasAllPermissions()) {
            ActivityCompat.requestPermissions(this, REQUIRED_PERMS, PERM_REQUEST)
        } else {
            startService(Intent(this, MavisService::class.java))
        }
    }

    private fun hasAllPermissions(): Boolean =
        REQUIRED_PERMS.all {
            ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
        }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERM_REQUEST && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
            startService(Intent(this, MavisService::class.java))
        } else {
            Toast.makeText(this, "Some features need permissions to work.", Toast.LENGTH_LONG).show()
        }
    }

    private fun showHelp() {
        val text = brain.helpText()
        AlertDialog.Builder(this)
            .setTitle("What I can do")
            .setMessage(text)
            .setPositiveButton("OK", null)
            .show()
    }

    private fun onMicTapped() {
        if (recognizer != null) {
            recognizer?.stopListening()
            recognizer?.destroy()
            recognizer = null
            return
        }
        startListening()
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Speech recognition not available on this device.", Toast.LENGTH_LONG).show()
            return
        }
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { status("Listening…") }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { status("Processing…") }
                override fun onError(error: Int) {
                    status("Try again. (err $error)")
                    recognizer?.destroy()
                    recognizer = null
                }
                override fun onResults(results: Bundle?) {
                    val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    recognizer?.destroy()
                    recognizer = null
                    if (text.isNullOrBlank()) { status("Heard nothing."); return }
                    onHeard(text)
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.US.toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        recognizer?.startListening(intent)
    }

    private fun onHeard(text: String) {
        youText.text = "You: $text"
        appendLog("you: $text")
        val intent: Intent = brain.parse(text)
        val reply = brain.handle(intent)
        mavisText.text = "Mavis: $reply"
        appendLog("mavis: $reply")
        speak(reply)
        status("Tap mic to speak again.")
    }

    private fun speak(text: String) {
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "mavis-${System.currentTimeMillis()}")
    }

    private fun status(s: String) { statusText.text = s }

    private fun appendLog(s: String) {
        logText.append("\n$s")
        logView.post { logView.fullScroll(View.FOCUS_DOWN) }
    }

    override fun onDestroy() {
        tts.stop()
        tts.shutdown()
        recognizer?.destroy()
        super.onDestroy()
    }
}

package com.mavis.assistant.brain.handlers

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.MediaStore
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.*

/**
 * All action handlers for Mavis. Each returns a string reply that the brain will speak.
 */
class Handlers(private val ctx: Context) {

    // ---- system info ----
    fun battery(): String {
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        return "Battery is at $level%."
    }

    // ---- math ----
    fun calc(expr: String): String {
        // safe expression evaluator for + - * / % ^ ( )
        val s = expr.lowercase()
            .replace("plus", "+").replace("minus", "-")
            .replace("times", "*").replace("multiplied by", "*")
            .replace("divided by", "/").replace("x", "*")
        val cleaned = s
            .replace("what is", "").replace("what's", "")
            .replace("calculate", "").replace("compute", "")
            .trim()
        return try {
            val result = evalExpr(cleaned)
            "That's $result."
        } catch (e: Exception) {
            "I couldn't compute that."
        }
    }

    private fun evalExpr(s: String): Double {
        // shunting-yard
        val output = ArrayDeque<Double>()
        val ops = ArrayDeque<Char>()
        val prec = mapOf('+' to 1, '-' to 1, '*' to 2, '/' to 2, '%' to 2, '^' to 3)
        var i = 0
        while (i < s.length) {
            val c = s[i]
            when {
                c.isWhitespace() -> i++
                c.isDigit() || c == '.' -> {
                    var j = i
                    while (j < s.length && (s[j].isDigit() || s[j] == '.')) j++
                    output.addLast(s.substring(i, j).toDouble())
                    i = j
                }
                c == '(' -> { ops.addLast(c); i++ }
                c == ')' -> {
                    while (ops.isNotEmpty() && ops.last() != '(') applyOp(output, ops.removeLast())
                    if (ops.isNotEmpty()) ops.removeLast()
                    i++
                }
                c in "+-*/%^" -> {
                    while (ops.isNotEmpty() && ops.last() != '(' &&
                        (prec[ops.last()] ?: 0) >= (prec[c] ?: 0)) {
                        applyOp(output, ops.removeLast())
                    }
                    ops.addLast(c); i++
                }
                else -> i++  // skip unknown chars
            }
        }
        while (ops.isNotEmpty()) applyOp(output, ops.removeLast())
        return output.last()
    }

    private fun applyOp(out: ArrayDeque<Double>, op: Char) {
        val b = out.removeLast(); val a = out.removeLast()
        val r = when (op) {
            '+' -> a + b; '-' -> a - b; '*' -> a * b; '/' -> a / b
            '%' -> a % b; '^' -> a.pow(b); else -> 0.0
        }
        out.addLast(r)
    }

    // ---- contacts (basic) ----
    private fun resolveContact(name: String): String? {
        // In a full app, query ContactsContract.Contacts. For demo, look up
        // a simple file the user can maintain: /sdcard/Mavis/contacts.txt
        return try {
            val f = File(ctx.getExternalFilesDir(null), "contacts.txt")
            if (!f.exists()) return null
            f.readLines().forEach { line ->
                val parts = line.split(":", limit = 2)
                if (parts.size == 2 && parts[0].trim().equals(name, ignoreCase = true)) {
                    return parts[1].trim()
                }
            }
            null
        } catch (e: Exception) { null }
    }

    // ---- call ----
    fun call(nameOrNumber: String): String {
        val number = resolveContact(nameOrNumber) ?: nameOrNumber
        val digits = number.filter { it.isDigit() || it == '+' }
        if (digits.isEmpty()) return "I don't have a number for $nameOrNumber."
        val i = Intent(Intent.ACTION_CALL, Uri.parse("tel:$digits")).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try { ctx.startActivity(i); "Calling $digits." }
        catch (e: SecurityException) { "I need call permission to make calls." }
    }

    // ---- sms ----
    fun sms(nameOrNumber: String, message: String): String {
        val number = resolveContact(nameOrNumber) ?: nameOrNumber
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("sms:$number")).apply {
            putExtra("sms_body", message)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try { ctx.startActivity(i); "Opening text to $number with: $message." }
        catch (e: Exception) { "Couldn't open messaging." }
    }

    // ---- whatsapp ----
    fun whatsapp(nameOrNumber: String, message: String): String {
        val number = resolveContact(nameOrNumber)?.filter { it.isDigit() } ?: nameOrNumber.filter { it.isDigit() }
        val url = "https://wa.me/$number?text=" + Uri.encode(message)
        val i = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try { ctx.startActivity(i); "Opening WhatsApp for $number." }
        catch (e: Exception) { "WhatsApp isn't installed." }
    }

    // ---- alarm ----
    fun setAlarm(time: String): String {
        val parts = time.split(":")
        if (parts.size != 2) return "I need a time like 7:30."
        val (h, m) = parts[0].toInt() to parts[1].toInt()
        val i = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, h)
            putExtra(AlarmClock.EXTRA_MINUTES, m)
            putExtra(AlarmClock.EXTRA_MESSAGE, "Mavis alarm")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try { ctx.startActivity(i); "Alarm set for $time." }
        catch (e: Exception) { "Couldn't set alarm." }
    }

    // ---- reminder ----
    fun setReminder(delaySeconds: Long, task: String): String {
        if (delaySeconds <= 0) return "Tell me 'in 5 minutes to ...' please."
        Thread {
            Thread.sleep(delaySeconds * 1000)
            // Real implementation: post a notification + speak via TTS service.
            // For demo we just rely on a sticky notification triggered by caller.
        }.start()
        return "I'll remind you to $task in ${humanize(delaySeconds)}."
    }

    // ---- timer ----
    fun setTimer(duration: Long): String {
        if (duration <= 0) return "How long?"
        Thread { Thread.sleep(duration * 1000) }.start()
        return "Timer started for ${humanize(duration)}."
    }

    // ---- open app ----
    fun openApp(name: String): String {
        val pkg = APP_ALIASES[name.lowercase()] ?: return "I don't know the app $name."
        val i = ctx.packageManager.getLaunchIntentForPackage(pkg)
        return if (i != null) {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
            "Opening $name."
        } else "$name isn't installed."
    }

    // ---- web search ----
    fun webSearch(query: String): String {
        val url = "https://www.google.com/search?q=" + Uri.encode(query)
        val i = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try { ctx.startActivity(i); "Searching for $query." }
        catch (e: Exception) { "Couldn't open browser." }
    }

    // ---- notes ----
    private fun notesFile(): File = File(ctx.getExternalFilesDir(null), "notes.txt")
    private fun todoFile(): File = File(ctx.getExternalFilesDir(null), "todo.txt")

    fun addNote(text: String): String {
        notesFile().appendText("[${SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())}] $text\n")
        return "Noted."
    }

    fun readNotes(): String {
        val f = notesFile()
        if (!f.exists()) return "No notes yet."
        val lines = f.readLines().filter { it.isNotBlank() }
        return if (lines.isEmpty()) "No notes yet." else "Your last notes: ${lines.takeLast(3).joinToString(" ... ")}"
    }

    fun clearNotes(): String { if (notesFile().exists()) notesFile().delete(); return "Notes cleared." }

    fun addTodo(task: String): String { todoFile().appendText("- $task\n"); return "Added: $task." }

    fun listTodo(): String {
        val f = todoFile()
        if (!f.exists()) return "Your to-do list is empty."
        val items = f.readLines().filter { it.isNotBlank() }
        return if (items.isEmpty()) "Your to-do list is empty." else "You have ${items.take(5).joinToString("; ")}"
    }

    // ---- hardware ----
    fun toggleFlashlight(on: Boolean): String {
        // CameraManager-based torch toggle. Requires CAMERA permission.
        return try {
            val cam = ctx.getSystemService(Context.CAMERA_SERVICE) as android.hardware.camera2.CameraManager
            val camId = cam.cameraIdList.firstOrNull { id ->
                cam.getCameraCharacteristics(id)
                    .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return "No flash available."
            cam.setTorchMode(camId, on)
            "Flashlight ${if (on) "on" else "off"}."
        } catch (e: Exception) { "Couldn't toggle flashlight: ${e.message}" }
    }

    fun toggleWifi(on: Boolean): String {
        val i = Intent(android.provider.Settings.ACTION_WIFI_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        // Programmatic wifi toggle requires WRITE_SECURE_SETTINGS (system app).
        // We just deep-link to the settings page.
        ctx.startActivity(i)
        return "Opening Wi-Fi settings."
    }

    fun toggleBluetooth(on: Boolean): String {
        val i = Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        ctx.startActivity(i)
        return "Opening Bluetooth settings."
    }

    fun setVolume(mute: Boolean): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
        am.ringerMode = if (mute) android.media.AudioManager.RINGER_MODE_SILENT
                        else android.media.AudioManager.RINGER_MODE_NORMAL
        return if (mute) "Phone muted." else "Phone unmuted."
    }

    fun adjustVolume(direction: String): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
        val dir = if (direction == "up") android.media.AudioManager.ADJUST_RAISE
                  else android.media.AudioManager.ADJUST_LOWER
        repeat(3) { am.adjustStreamVolume(android.media.AudioManager.STREAM_MUSIC, dir, 0) }
        return "Volume $direction."
    }

    fun openCamera(): String {
        val i = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try { ctx.startActivity(i); "Opening camera." }
        catch (e: Exception) { "Camera not available." }
    }

    fun screenshot(): String {
        // Screenshots require MediaProjection, which needs user confirmation via a system dialog.
        // For now, deep-link to the recent-screenshot in Photos.
        val i = Intent(Intent.ACTION_VIEW).apply {
            type = "image/*"
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try { ctx.startActivity(i); "Opening photos." }
        catch (e: Exception) { "Couldn't open photos." }
    }

    // ---- helpers ----
    private fun humanize(s: Long): String {
        if (s < 60) return "$s seconds"
        if (s < 3600) return "${s / 60} minutes"
        val h = s / 3600
        val m = (s % 3600) / 60
        return if (m == 0L) "$h hour${if (h != 1L) "s" else ""}" else "$h hour${if (h != 1L) "s" else ""} $m minutes"
    }

    companion object {
        val APP_ALIASES = mapOf(
            "youtube" to "com.google.android.youtube",
            "chrome" to "com.android.chrome",
            "gmail" to "com.google.android.gm",
            "maps" to "com.google.android.apps.maps",
            "settings" to "com.android.settings",
            "camera" to "com.android.camera",
            "calculator" to "com.android.calculator2",
            "calendar" to "com.google.android.calendar",
            "photos" to "com.google.android.apps.photos",
            "play store" to "com.android.vending",
            "messages" to "com.google.android.apps.messaging",
            "phone" to "com.android.dialer",
            "contacts" to "com.android.contacts",
            "clock" to "com.google.android.deskclock",
            "spotify" to "com.spotify.music",
            "instagram" to "com.instagram.android",
            "facebook" to "com.facebook.katana",
            "twitter" to "com.twitter.android",
            "x" to "com.twitter.android",
            "telegram" to "org.telegram.messenger",
            "whatsapp" to "com.whatsapp",
            "files" to "com.android.documentsui",
            "notes" to "com.google.android.keep",
        )
    }
}

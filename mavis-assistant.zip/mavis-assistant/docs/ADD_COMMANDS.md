# Adding Custom Commands to Mavis

The brain is a rule-based intent parser. Adding a new command = 1 regex + 1 handler.

## Step 1: Define the pattern

In `brain.py` (Python) or `Brain.kt` (Kotlin), add to the `register_defaults()` method.

### Python example — "play X on spotify"

```python
C.append({
    "patterns": [
        r"play (.+?) on spotify",
        r"open spotify and play (.+)",
    ],
    "intent": "play_spotify",
    "extract": lambda m: {"song": m.group(1).strip()},
})
```

### Kotlin example — same

```kotlin
cmds.add(Cmd(
    listOf(
        "play (.+?) on spotify".toRegex(),
        "open spotify and play (.+)".toRegex()
    ),
    "play_spotify",
    { m -> mapOf("song" to m.groupValues[1].trim()) }
))
```

## Step 2: Add a handler

### Python (Termux) — `mavis.py`

```python
elif name == "play_spotify":
    song = p.get("song", "")
    r = termux_api(["termux-open", f"spotify:search:{urllib.parse.quote(song)}"])
    return f"Playing {song} on Spotify."
```

### Python (PC controller) — `mavis_pc.py`

```python
# in handle() dispatch dict:
"play_spotify": lambda: play_spotify(p.get("song", "")),

# and the function:
def play_spotify(song):
    from urllib.parse import quote
    adb_shell(f"am start -a android.intent.action.VIEW -d 'spotify:search:{quote(song)}'")
    return f"Playing {song} on Spotify."
```

### Kotlin (Android) — `Handlers.kt`

```kotlin
fun playSpotify(song: String): String {
    val i = Intent(Intent.ACTION_VIEW, Uri.parse("spotify:search:${Uri.encode(song)}"))
    return try {
        ctx.startActivity(i)
        "Playing $song on Spotify."
    } catch (e: Exception) { "Spotify isn't installed." }
}
```

Then wire in `Brain.kt` `handle()`:

```kotlin
"play_spotify" -> handlers.playSpotify(intent.params["song"] ?: "")
```

## Step 3: Test

```bash
# Termux / PC
python mavis.py --text
> play never gonna give you up on spotify

# Or in voice mode:
hey mavis play never gonna give you up on spotify
```

For Android: rebuild the APK and reinstall.

## Regex cheatsheet

| Want | Regex |
|---|---|
| Exact phrase | `"set alarm"`.toRegex() |
| Word | `r"\bhello\b"` (Python), `"\\bhello\\b".toRegex()` (Kotlin) |
| Optional word | `r"set (?:a )?timer"` |
| Capture group | `r"play (.+) on spotify"` → `m.group(1)` |
| Number | `r"\d+"` |
| 1 or more digits | `r"\d+"` |
| Word boundary | `r"\b...\b"` |

## Pre-built helpers in the engine

| Helper | What it does |
|---|---|
| `parseTime(s)` | "7am", "7:30 pm", "19:00" → "07:00", "19:30" |
| `parseDuration(s)` | "10 minutes", "2 hours" → seconds (int) |
| `_resolve_contact(name)` | looks up `~/.mavis/contacts.json` |
| `safe_calc(expr)` | safe math eval (no shell injection) |
| `random.choice(JOKES/FACTS)` | built-in fun content |

## Common patterns to add

```python
# Translate (uses local phrasebook, no API)
{"patterns": [r"how do you say (.+) in spanish"], "intent": "translate",
 "extract": lambda m: {"word": m.group(1)}},

# Unit convert (no API, just math)
{"patterns": [r"convert (\d+\.?\d*) (\w+) to (\w+)"], "intent": "convert_units",
 "extract": lambda m: {"val": m.group(1), "from": m.group(2), "to": m.group(3)}},

# Read clipboard
{"patterns": [r"read (?:my )?clipboard", r"what('?s| is) on my clipboard"], "intent": "read_clipboard"},

# Set Do Not Disturb
{"patterns": [r"(turn on|turn off|enable|disable) dnd",
              r"(turn on|turn off|enable|disable) do not disturb"], "intent": "set_dnd",
 "extract": lambda m: {"on": "on" in m.group(1) or "enable" in m.group(1)}},
```

Have fun! 🚀

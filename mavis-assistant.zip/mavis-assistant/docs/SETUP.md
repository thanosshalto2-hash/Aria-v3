# Mavis — Complete Setup Guide

A fully self-contained personal voice assistant. **No LLM, no cloud, no API keys.**

Three flavors — pick the one that fits you:

---

## Quick comparison

| Flavor | Build time | Where the mic is | What you get |
|---|---|---|---|
| **A. Termux** (Python on phone) | 5 min | Phone | Background listening on the phone itself |
| **B. PC Controller** (Python on PC) | 10 min | PC | Speak into your laptop, phone executes |
| **C. Android APK** (Kotlin) | 20 min (Android Studio) | Phone | Real native app with foreground service |

**Recommended: start with Termux (5 min, no build).** Upgrade to APK later if you want.

---

## Flavor A — Termux (recommended for fastest start)

### One-time setup (~5 min)

1. **Install Termux from F-Droid.** Play Store version is outdated.
   - https://f-droid.org/en/packages/com.termux/
   - https://f-droid.org/en/packages/com.termux.api/  ← also install this one

2. **Grant Termux permissions:** Settings → Apps → Termux → Permissions → enable Microphone, Storage, Contacts, Phone, SMS.

3. **Open Termux:API app once** and accept all prompts.

4. **Paste this into Termux:**
   ```bash
   pkg update -y && pkg upgrade -y
   pkg install python termux-api git curl unzip -y
   pip install vosk sounddevice
   cd ~
   curl -L -o vosk-model.zip https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip
   unzip -q vosk-model.zip && mv vosk-model-small-en-us-0.15 vosk-model && rm vosk-model.zip
   termux-setup-storage
   ```

5. **Get the Mavis code on your phone.** Easiest: download this whole `mavis-assistant` folder to your phone (via USB, Drive, or `git clone`), then:
   ```bash
   cd ~/storage/downloads/mavis-assistant/termux
   # (or wherever you put it)
   python mavis.py --text    # test in text mode first
   python mavis.py           # then voice mode
   ```

### Try these

```
hey mavis what is the time
hey mavis set alarm for 7am
hey mavis call mom
hey mavis remind me in 5 minutes to drink water
hey mavis open youtube
hey mavis tell me a joke
hey mavis goodbye
```

### Customizing contacts

```bash
mkdir -p ~/.mavis
cat > ~/.mavis/contacts.json <<EOF
{
  "mom":   "+15551234567",
  "dad":   "+15559876543",
  "john":  "+15551112222"
}
EOF
```

---

## Flavor B — PC Controller (no APK on phone)

### One-time setup

1. **Install adb** on your PC:
   - macOS: `brew install android-platform-tools`
   - Ubuntu/Debian: `sudo apt install adb`
   - Windows: download from https://developer.android.com/studio/releases/platform-tools

2. **On phone:** Settings → About phone → tap "Build number" 7 times → Developer options → USB debugging ON.

3. **Plug phone into PC**, accept the USB debugging popup on phone.

4. **Verify connection:**
   ```bash
   adb devices
   # should list your phone
   ```

5. **Set up Vosk model:**
   ```bash
   cd ~
   curl -L -o vosk-model.zip https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip
   unzip vosk-model.zip && mv vosk-model-small-en-us-0.15 vosk-model && rm vosk-model.zip
   ```

6. **Install Python deps:**
   ```bash
   pip install vosk sounddevice pyttsx3
   ```

7. **Run:**
   ```bash
   cd mavis-assistant/pc-controller
   python mavis_pc.py
   ```

### Wireless (no USB cable)

```bash
adb tcpip 5555
adb connect 192.168.1.42:5555   # use your phone's IP
python mavis_pc.py --device 192.168.1.42:5555
```

---

## Flavor C — Android APK (native, most polished)

### Build with Android Studio

1. Open Android Studio (Hedgehog / 2023.1+)
2. File → Open → select `mavis-assistant/android-app/`
3. Wait for Gradle sync
4. Build → Build Bundle(s) / APK(s) → Build APK(s)
5. Install the APK: `adb install app/build/outputs/apk/debug/app-debug.apk`
   (or just copy the APK to phone and tap to install — enable "Install unknown apps" first)

### Build with command line

```bash
cd mavis-assistant/android-app
gradle wrapper        # one-time, generates ./gradlew
./gradlew assembleDebug
adb install app/build/outputs/apk/debug/app-debug.apk
```

### First launch

Grant the permissions it asks for (mic, phone, SMS, contacts, camera). Tap the big purple mic, speak, done.

---

## Adding your own commands

Whichever flavor you pick, the brain is a rule engine. Adding a new command is just:

### In Termux/PC (Python)

Edit `brain.py`, find `_register_defaults`, add:

```python
C.append({
    "patterns": [r"play (.+) on spotify"],
    "intent": "play_spotify",
    "extract": lambda m: {"song": m.group(1).strip()},
})
```

Then add a handler in `mavis.py` (or `mavis_pc.py`):

```python
elif name == "play_spotify":
    return open_app(f"spotify:search:{p.get('song','')}")
```

Restart. Done.

### In Android (Kotlin)

Edit `Brain.kt`, find `registerDefaults()`, add:

```kotlin
cmds.add(Cmd(
    listOf("play (.+) on spotify".toRegex()),
    "play_spotify",
    { m -> mapOf("song" to m.groupValues[1].trim()) }
))
```

Then add a handler in `Handlers.kt` and wire it in `Brain.handle()`. Rebuild the APK.

---

## What's built-in (all 3 versions)

✅ Time, date, battery
✅ Calls, SMS, WhatsApp
✅ Alarms, reminders, timers
✅ Open apps (30+ pre-configured)
✅ Web search (opens browser)
✅ Notes & to-do list (saved locally)
✅ Flashlight, WiFi, Bluetooth (deep-link to settings on Android)
✅ Camera, screenshots
✅ Jokes, fun facts
✅ Calculator
✅ Wake word "hey mavis"
✅ Help, exit, thanks

---

## What it CAN'T do (honest list)

❌ iOS control (Apple blocks it; use the PC controller with limited functionality)
❌ True always-on wake word without keeping app foreground (Android: needs foreground service + Vosk init)
❌ Programmatic WiFi/Bluetooth toggle on modern Android (we deep-link to settings)
❌ Smart conversation (it's rule-based; if you want chat, add an LLM later)
❌ Hold a real phone call or read SMS contents back (Android sandbox)

---

## Upgrading later

When you outgrow the rule engine, drop in a small local LLM:
- **Termux/PC:** add `llama-cpp-python`, route `unknown` intents to it
- **Android:** bundle a 1B-3B model with llama.cpp JNI, ~50MB

The architecture is already shaped for it — `Brain.parse()` returns an Intent, and your LLM just needs to return the same shape.

---

## License

MIT. Use it, fork it, ship it. Built by Mavis.

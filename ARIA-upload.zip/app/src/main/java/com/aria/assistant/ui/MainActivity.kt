package com.aria.assistant.ui

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.KeyEvent
import android.view.inputmethod.EditorInfo
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.aria.assistant.databinding.ActivityMainBinding
import com.aria.assistant.service.VoiceService
import com.aria.assistant.utils.BatteryOptimizationHelper
import com.aria.assistant.utils.CommandProcessor
import com.aria.assistant.utils.ConversationDatabase
import com.aria.assistant.utils.MessageEntity
import com.aria.assistant.utils.PermissionHelper
import com.aria.assistant.utils.PrefsManager
import com.aria.assistant.utils.TTSManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: PrefsManager
    private lateinit var tts: TTSManager
    private lateinit var commandProcessor: CommandProcessor
    private lateinit var chatAdapter: ChatAdapter
    private lateinit var db: ConversationDatabase
    private val chatMessages = mutableListOf<ChatMessage>()

    companion object { private const val PERM_REQUEST = 100 }

    private val serviceReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val command  = intent.getStringExtra(VoiceService.EXTRA_COMMAND) ?: return
            val response = intent.getStringExtra(VoiceService.EXTRA_RESPONSE) ?: return
            if (command.isNotBlank()) {
                addMessage("you", command)
                saveToDb("user", command)
            }
            if (response.isNotBlank() && response != "...") {
                addMessage("aria", response)
                saveToDb("assistant", response)
                setListeningState(false)
            } else if (response == "...") {
                setListeningState(true)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = PrefsManager(this)
        tts   = TTSManager(this)
        commandProcessor = CommandProcessor(this)
        db    = ConversationDatabase.getInstance(this)

        setupRecyclerView()
        setupInputBar()
        setupButtons()

        registerReceiver(
            serviceReceiver,
            IntentFilter(VoiceService.ACTION_COMMAND_RESULT),
            RECEIVER_NOT_EXPORTED
        )

        // Request permissions → start service
        val missing = PermissionHelper.missing(this)
        if (missing.isEmpty()) {
            onPermissionsReady()
        } else {
            ActivityCompat.requestPermissions(this, missing, PERM_REQUEST)
        }

        addMessage("aria", "Hey! I'm ARIA. Say \"${prefs.wakeWord}\" or type below.\n\nI can: call people, send texts, open apps, search Google, set alarms, control media, navigate, and answer anything with AI.")
    }

    override fun onDestroy() {
        unregisterReceiver(serviceReceiver)
        tts.shutdown()
        super.onDestroy()
    }

    // ── UI ────────────────────────────────────────────────────────────────────

    private fun setupRecyclerView() {
        chatAdapter = ChatAdapter(chatMessages)
        binding.recyclerView.apply {
            layoutManager = LinearLayoutManager(this@MainActivity).apply { stackFromEnd = true }
            adapter = chatAdapter
        }
    }

    private fun setupInputBar() {
        binding.editTextInput.setOnEditorActionListener { _, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_SEND ||
                (event?.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)) {
                sendTextCommand(); true
            } else false
        }
        binding.btnSend.setOnClickListener { sendTextCommand() }
    }

    private fun setupButtons() {
        binding.btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        binding.btnMic.setOnClickListener {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                if (isServiceRunning()) {
                    stopService(Intent(this, VoiceService::class.java))
                    binding.btnMic.setImageResource(android.R.drawable.ic_btn_speak_now)
                    setListeningState(false)
                    addMessage("aria", "Voice listening stopped.")
                } else {
                    startVoiceService()
                    addMessage("aria", "Voice listening started. Say \"${prefs.wakeWord}\"!")
                }
            } else {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), PERM_REQUEST)
            }
        }
        binding.btnClear.setOnClickListener {
            chatMessages.clear()
            chatAdapter.notifyDataSetChanged()
        }
    }

    private fun sendTextCommand() {
        val text = binding.editTextInput.text.toString().trim()
        if (text.isBlank()) return
        binding.editTextInput.setText("")
        addMessage("you", text)
        saveToDb("user", text)
        setLoadingState(true)

        commandProcessor.process(text) { response ->
            addMessage("aria", response)
            saveToDb("assistant", response)
            setLoadingState(false)
        }
    }

    fun addMessage(role: String, text: String) {
        chatMessages.add(ChatMessage(role, text, System.currentTimeMillis()))
        chatAdapter.notifyItemInserted(chatMessages.size - 1)
        binding.recyclerView.smoothScrollToPosition(chatMessages.size - 1)
    }

    private fun saveToDb(role: String, content: String) {
        lifecycleScope.launch(Dispatchers.IO) {
            db.messageDao().insert(MessageEntity(role = role, content = content))
        }
    }

    private fun setListeningState(listening: Boolean) {
        binding.statusText.text = if (listening) "Listening..." else "Say \"${prefs.wakeWord}\""
        binding.waveformView.isActive = listening
    }

    private fun setLoadingState(loading: Boolean) {
        binding.progressBar.visibility = if (loading) android.view.View.VISIBLE else android.view.View.GONE
        binding.btnSend.isEnabled = !loading
    }

    // ── Service ───────────────────────────────────────────────────────────────

    private fun startVoiceService() {
        ContextCompat.startForegroundService(this, Intent(this, VoiceService::class.java))
    }

    @Suppress("DEPRECATION")
    private fun isServiceRunning(): Boolean {
        val am = getSystemService(ACTIVITY_SERVICE) as android.app.ActivityManager
        return am.getRunningServices(Int.MAX_VALUE).any {
            it.service.className == VoiceService::class.java.name
        }
    }

    private fun onPermissionsReady() {
        startVoiceService()
        // Ask to disable battery optimization so service survives
        if (!BatteryOptimizationHelper.isIgnoringBatteryOptimizations(this)) {
            BatteryOptimizationHelper.requestIgnoreBatteryOptimizations(this)
        }
    }

    // ── Permissions ───────────────────────────────────────────────────────────

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERM_REQUEST) {
            val denied = permissions.zip(grantResults.toList()).filter { it.second != PackageManager.PERMISSION_GRANTED }.map { it.first }
            if (denied.isNotEmpty()) {
                Toast.makeText(this, "Some features limited — ${denied.size} permission(s) denied", Toast.LENGTH_LONG).show()
            }
            onPermissionsReady()
        }
    }
}

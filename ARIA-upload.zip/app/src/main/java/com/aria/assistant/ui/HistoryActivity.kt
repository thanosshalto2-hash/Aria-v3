package com.aria.assistant.ui

import android.os.Bundle
import android.view.MenuItem
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.widget.ImageButton
import android.widget.TextView
import com.aria.assistant.R
import com.aria.assistant.utils.ConversationDatabase
import com.aria.assistant.utils.MessageEntity
import kotlinx.coroutines.launch
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

class HistoryActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var db: ConversationDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Build layout programmatically — no extra XML needed
        val layout = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setBackgroundColor(android.graphics.Color.parseColor("#080a0f"))
        }

        recyclerView = RecyclerView(this).apply {
            layoutParams = android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT
            )
            setPadding(24, 16, 24, 16)
            layoutManager = LinearLayoutManager(this@HistoryActivity)
        }

        layout.addView(recyclerView)
        setContentView(layout)

        supportActionBar?.apply {
            setDisplayHomeAsUpEnabled(true)
            title = "Conversation History"
        }

        db = ConversationDatabase.getInstance(this)
        loadHistory()
    }

    private fun loadHistory() {
        lifecycleScope.launch {
            val messages = db.messageDao().getRecent(200)
            recyclerView.adapter = HistoryAdapter(messages.reversed())
        }
    }

    private fun clearHistory() {
        AlertDialog.Builder(this)
            .setTitle("Clear History")
            .setMessage("Delete all conversation history?")
            .setPositiveButton("Delete") { _, _ ->
                lifecycleScope.launch {
                    db.messageDao().deleteAll()
                    loadHistory()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) { finish(); return true }
        return super.onOptionsItemSelected(item)
    }

    // Inline adapter
    inner class HistoryAdapter(private val items: List<MessageEntity>) :
        RecyclerView.Adapter<RecyclerView.ViewHolder>() {

        inner class VH(val tv: TextView) : RecyclerView.ViewHolder(tv)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val tv = TextView(parent.context).apply {
                layoutParams = ViewGroup.MarginLayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { setMargins(0, 8, 0, 8) }
                setPadding(32, 20, 32, 20)
                textSize = 13f
                typeface = android.graphics.Typeface.MONOSPACE
                setLineSpacing(0f, 1.4f)
            }
            return VH(tv)
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
            val item = items[position]
            val vh = holder as VH
            if (item.role == "user") {
                vh.tv.text = "YOU: ${item.content}"
                vh.tv.setTextColor(android.graphics.Color.parseColor("#e2e8f0"))
                vh.tv.setBackgroundColor(android.graphics.Color.parseColor("#1a2030"))
            } else {
                vh.tv.text = "ARIA: ${item.content}"
                vh.tv.setTextColor(android.graphics.Color.parseColor("#00E5FF"))
                vh.tv.setBackgroundColor(android.graphics.Color.parseColor("#0d1a2e"))
            }
        }

        override fun getItemCount() = items.size
    }
}

package com.aria.assistant.utils

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat

object PermissionHelper {

    val ALL_PERMISSIONS = arrayOf(
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.CALL_PHONE,
        Manifest.permission.READ_CONTACTS,
        Manifest.permission.SEND_SMS,
        Manifest.permission.READ_SMS,
        Manifest.permission.POST_NOTIFICATIONS,
    )

    fun hasAudio(context: Context) = has(context, Manifest.permission.RECORD_AUDIO)
    fun hasCall(context: Context)  = has(context, Manifest.permission.CALL_PHONE)
    fun hasSms(context: Context)   = has(context, Manifest.permission.SEND_SMS)
    fun hasContacts(context: Context) = has(context, Manifest.permission.READ_CONTACTS)

    fun missing(context: Context): Array<String> =
        ALL_PERMISSIONS.filter { !has(context, it) }.toTypedArray()

    private fun has(context: Context, permission: String) =
        ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
}

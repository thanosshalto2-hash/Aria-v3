package com.aria.assistant.utils

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.provider.AlarmClock
import java.util.Calendar
import java.util.regex.Pattern

/**
 * AlarmHandler — parses natural language time and sets system alarms.
 *
 * Examples handled:
 *   "set alarm for 7am"
 *   "wake me up at 6:30"
 *   "set alarm for tomorrow 8am"
 *   "set timer for 5 minutes"
 *   "remind me in 10 minutes"
 */
object AlarmHandler {

    fun handle(text: String, context: Context): String {
        return when {
            isTimer(text) -> setTimer(text, context)
            else          -> setAlarm(text, context)
        }
    }

    private fun isTimer(text: String) =
        text.contains(Regex("timer|in \\d+ (minute|second|hour|min|sec|hr)"))

    // ─── Timer ────────────────────────────────────────────────────────────────

    private fun setTimer(text: String, context: Context): String {
        val seconds = parseSeconds(text)
        if (seconds <= 0) return "How long should I set the timer for?"

        val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
            putExtra(AlarmClock.EXTRA_LENGTH, seconds)
            putExtra(AlarmClock.EXTRA_MESSAGE, "ARIA Timer")
            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }

        return try {
            context.startActivity(intent)
            val label = formatDuration(seconds)
            "Timer set for $label."
        } catch (e: Exception) {
            "Couldn't set timer. Is a clock app installed?"
        }
    }

    private fun parseSeconds(text: String): Int {
        val hourPattern   = Pattern.compile("(\\d+)\\s*(?:hour|hr)s?")
        val minutePattern = Pattern.compile("(\\d+)\\s*(?:minute|min)s?")
        val secondPattern = Pattern.compile("(\\d+)\\s*(?:second|sec)s?")

        var total = 0
        hourPattern.matcher(text).let { m -> if (m.find()) total += m.group(1).toInt() * 3600 }
        minutePattern.matcher(text).let { m -> if (m.find()) total += m.group(1).toInt() * 60 }
        secondPattern.matcher(text).let { m -> if (m.find()) total += m.group(1).toInt() }
        return total
    }

    private fun formatDuration(seconds: Int): String {
        val h = seconds / 3600
        val m = (seconds % 3600) / 60
        val s = seconds % 60
        return buildString {
            if (h > 0) append("$h hour${if (h > 1) "s" else ""} ")
            if (m > 0) append("$m minute${if (m > 1) "s" else ""} ")
            if (s > 0) append("$s second${if (s > 1) "s" else ""}")
        }.trim()
    }

    // ─── Alarm ────────────────────────────────────────────────────────────────

    private fun setAlarm(text: String, context: Context): String {
        val (hour, minute) = parseTime(text) ?: return "I couldn't parse that time. Try: 'set alarm for 7:30am'."

        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, hour)
            putExtra(AlarmClock.EXTRA_MINUTES, minute)
            putExtra(AlarmClock.EXTRA_MESSAGE, "ARIA Alarm")
            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }

        return try {
            context.startActivity(intent)
            val amPm = if (hour < 12) "AM" else "PM"
            val displayHour = if (hour == 0) 12 else if (hour > 12) hour - 12 else hour
            val displayMin = minute.toString().padStart(2, '0')
            "Alarm set for $displayHour:$displayMin $amPm."
        } catch (e: Exception) {
            "Couldn't set alarm. Is a clock app installed?"
        }
    }

    private fun parseTime(text: String): Pair<Int, Int>? {
        // Match patterns: 7am, 7:30am, 7:30 am, 19:00, 7 30 am
        val patterns = listOf(
            Pattern.compile("(\\d{1,2}):(\\d{2})\\s*(am|pm)?", Pattern.CASE_INSENSITIVE),
            Pattern.compile("(\\d{1,2})\\s*(am|pm)", Pattern.CASE_INSENSITIVE),
            Pattern.compile("(\\d{1,2})\\s+(\\d{2})\\s*(am|pm)?", Pattern.CASE_INSENSITIVE)
        )

        for (pattern in patterns) {
            val matcher = pattern.matcher(text)
            if (matcher.find()) {
                var hour = matcher.group(1)?.toIntOrNull() ?: continue
                val minute = matcher.group(2)?.toIntOrNull() ?: 0
                val amPm = try { matcher.group(3)?.lowercase() } catch (e: Exception) { null }

                // Convert to 24h
                if (amPm == "pm" && hour != 12) hour += 12
                if (amPm == "am" && hour == 12) hour = 0

                // Clamp
                if (hour in 0..23 && minute in 0..59) {
                    return Pair(hour, minute)
                }
            }
        }
        return null
    }
}

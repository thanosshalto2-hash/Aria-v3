package com.aria.assistant.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import kotlin.math.sin

/**
 * WaveformView — animated sine-wave bars that pulse when ARIA is listening.
 * Pure Canvas drawing, no libs needed.
 */
class WaveformView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    var isActive: Boolean = false
        set(value) {
            field = value
            if (value) startAnimation() else stopAnimation()
            invalidate()
        }

    private val barCount = 20
    private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#00E5FF")
        strokeCap = Paint.Cap.ROUND
        strokeWidth = 6f
    }

    private var phase = 0f
    private val runnable = object : Runnable {
        override fun run() {
            phase += 0.15f
            invalidate()
            if (isActive) postDelayed(this, 50)
        }
    }

    private fun startAnimation() {
        removeCallbacks(runnable)
        post(runnable)
    }

    private fun stopAnimation() {
        removeCallbacks(runnable)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        val midY = h / 2f
        val barWidth = w / (barCount * 2f)

        for (i in 0 until barCount) {
            val x = barWidth + i * (w / barCount)
            val amplitude = if (isActive) {
                val wave = sin(phase + i * 0.4).toFloat()
                ((wave + 1f) / 2f) * (h * 0.7f) + (h * 0.1f)
            } else {
                h * 0.08f
            }
            val alpha = if (isActive) 200 else 60
            barPaint.alpha = alpha
            canvas.drawLine(x, midY - amplitude / 2, x, midY + amplitude / 2, barPaint)
        }
    }
}

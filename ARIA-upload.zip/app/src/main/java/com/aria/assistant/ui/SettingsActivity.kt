package com.aria.assistant.ui

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.aria.assistant.databinding.ActivitySettingsBinding
import com.aria.assistant.utils.PrefsManager

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private lateinit var prefs: PrefsManager

    private val providers = arrayOf("openrouter", "ollama", "openai", "anthropic")
    private val providerLabels = arrayOf(
        "OpenRouter (Free — Recommended)",
        "Ollama (Local / Offline)",
        "OpenAI (GPT-4)",
        "Anthropic (Claude)"
    )

    private val freeModels = arrayOf(
        "mistralai/mistral-7b-instruct:free",
        "meta-llama/llama-3-8b-instruct:free",
        "google/gemma-7b-it:free",
        "anthropic/claude-haiku"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        title = "ARIA Settings"

        prefs = PrefsManager(this)
        loadSettings()
        setupProviderSpinner()

        binding.btnSave.setOnClickListener { saveSettings() }
    }

    private fun loadSettings() {
        binding.editWakeWord.setText(prefs.wakeWord)
        binding.editOpenRouterKey.setText(prefs.openRouterKey)
        binding.editOpenAIKey.setText(prefs.openAIKey)
        binding.editAnthropicKey.setText(prefs.anthropicKey)
        binding.editOllamaHost.setText(prefs.ollamaHost)
        binding.editOllamaModel.setText(prefs.ollamaModel)
        binding.switchAlwaysListening.isChecked = prefs.alwaysListening
        binding.switchVoiceResponse.isChecked = prefs.voiceEnabled
    }

    private fun setupProviderSpinner() {
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, providerLabels)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerProvider.adapter = adapter
        binding.spinnerProvider.setSelection(providers.indexOf(prefs.aiProvider).coerceAtLeast(0))
    }

    private fun saveSettings() {
        prefs.wakeWord = binding.editWakeWord.text.toString().trim().ifBlank { "hey aria" }
        prefs.aiProvider = providers[binding.spinnerProvider.selectedItemPosition]
        prefs.openRouterKey = binding.editOpenRouterKey.text.toString().trim()
        prefs.openAIKey = binding.editOpenAIKey.text.toString().trim()
        prefs.anthropicKey = binding.editAnthropicKey.text.toString().trim()
        prefs.ollamaHost = binding.editOllamaHost.text.toString().trim()
        prefs.ollamaModel = binding.editOllamaModel.text.toString().trim()
        prefs.alwaysListening = binding.switchAlwaysListening.isChecked
        prefs.voiceEnabled = binding.switchVoiceResponse.isChecked

        Toast.makeText(this, "Settings saved!", Toast.LENGTH_SHORT).show()
        finish()
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}

package com.aria.assistant

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build

class ARIAApp : Application() {

    companion object {
        const val CHANNEL_ID_VOICE = "aria_voice_service"
        const val CHANNEL_ID_ALERTS = "aria_alerts"
        lateinit var instance: ARIAApp
            private set
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val voiceChannel = NotificationChannel(
                CHANNEL_ID_VOICE,
                "ARIA Voice Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "ARIA is listening for your commands"
                setShowBadge(false)
            }

            val alertChannel = NotificationChannel(
                CHANNEL_ID_ALERTS,
                "ARIA Alerts",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "ARIA action alerts"
            }

            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(voiceChannel)
            nm.createNotificationChannel(alertChannel)
        }
    }
}

package com.aria.assistant.service

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import androidx.lifecycle.LifecycleService
import com.aria.assistant.ARIAApp
import com.aria.assistant.R
import com.aria.assistant.ui.MainActivity
import com.aria.assistant.utils.CommandProcessor
import com.aria.assistant.utils.PrefsManager

/**
 * VoiceService — runs in foreground, always listening.
 *
 * Architecture:
 *  - Foreground service with persistent notification (can't be killed by Android)
 *  - Uses Android SpeechRecognizer (on-device, free, works offline for basic commands)
 *  - On result: passes to CommandProcessor
 *  - Restarts itself after each recognition session (continuous loop)
 *
 * Wake word detection: lightweight string match on partial results.
 * After wake word detected → full command recognition mode.
 */
class VoiceService : LifecycleService() {

    companion object {
        const val TAG = "ARIA_Service"
        const val NOTIFICATION_ID = 1001
        const val ACTION_STOP = "com.aria.assistant.STOP_SERVICE"
        const val ACTION_COMMAND_RESULT = "com.aria.assistant.COMMAND_RESULT"
        const val EXTRA_COMMAND = "command"
        const val EXTRA_RESPONSE = "response"
    }

    private var speechRecognizer: SpeechRecognizer? = null
    private lateinit var prefs: PrefsManager
    private lateinit var commandProcessor: CommandProcessor
    private var isListeningForCommand = false
    private var isServiceRunning = false

    override fun onCreate() {
        super.onCreate()
        prefs = PrefsManager(this)
        commandProcessor = CommandProcessor(this)
        Log.d(TAG, "VoiceService created")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)

        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        if (!isServiceRunning) {
            isServiceRunning = true
            startForeground(NOTIFICATION_ID, buildNotification("Listening for \"${prefs.wakeWord}\"..."))
            startListening()
        }

        return START_STICKY   // Android will restart us if killed
    }

    override fun onDestroy() {
        isServiceRunning = false
        speechRecognizer?.destroy()
        super.onDestroy()
    }

    // ─── Listening loop ───────────────────────────────────────────────────────

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Log.e(TAG, "Speech recognition not available")
            updateNotification("Speech recognition unavailable on this device")
            return
        }

        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer?.setRecognitionListener(recognitionListener)

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            // Keep listening for up to 10 seconds of speech
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2000L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 2000L)
        }

        speechRecognizer?.startListening(intent)
        Log.d(TAG, if (isListeningForCommand) "Listening for command..." else "Listening for wake word...")
    }

    private val recognitionListener = object : RecognitionListener {

        override fun onPartialResults(partialResults: Bundle?) {
            val partial = partialResults
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
                ?.lowercase() ?: return

            Log.d(TAG, "Partial: $partial")

            // Wake word detection on partial results — fast response
            if (!isListeningForCommand) {
                val wakeWord = prefs.wakeWord.lowercase()
                if (partial.contains(wakeWord)) {
                    Log.d(TAG, "Wake word detected!")
                    isListeningForCommand = true
                    updateNotification("Listening for your command...")
                    broadcastToUI("", "I'm listening...")
                }
            }
        }

        override fun onResults(results: Bundle?) {
            val text = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
                ?.lowercase() ?: run {
                    restartListening()
                    return
                }

            Log.d(TAG, "Final result: $text")

            val wakeWord = prefs.wakeWord.lowercase()

            if (isListeningForCommand) {
                // Strip wake word from command if included
                val command = text.replace(wakeWord, "").trim()
                if (command.isNotBlank()) {
                    processCommand(command)
                } else {
                    restartListening()
                }
                isListeningForCommand = false

            } else if (text.contains(wakeWord)) {
                // Wake word + command in same utterance
                val command = text.substringAfter(wakeWord).trim()
                if (command.isNotBlank()) {
                    processCommand(command)
                } else {
                    isListeningForCommand = true
                    updateNotification("Listening for your command...")
                    broadcastToUI("", "I'm listening...")
                    restartListening()
                }
            } else {
                restartListening()
            }
        }

        override fun onError(error: Int) {
            val msg = when (error) {
                SpeechRecognizer.ERROR_AUDIO -> "Audio error"
                SpeechRecognizer.ERROR_CLIENT -> "Client error"
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "No mic permission"
                SpeechRecognizer.ERROR_NETWORK -> "Network error"
                SpeechRecognizer.ERROR_NO_MATCH -> "No speech detected"
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Recognizer busy"
                SpeechRecognizer.ERROR_SERVER -> "Server error"
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Speech timeout"
                else -> "Unknown error ($error)"
            }
            Log.w(TAG, "Recognition error: $msg")
            isListeningForCommand = false
            restartListening(delayMs = 500)
        }

        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private fun processCommand(command: String) {
        Log.d(TAG, "Processing command: $command")
        updateNotification("Processing: \"$command\"")
        broadcastToUI(command, "...")

        commandProcessor.process(command) { response ->
            updateNotification("Listening for \"${prefs.wakeWord}\"...")
            broadcastToUI(command, response)
            // Small delay so TTS can speak before we start listening again
            android.os.Handler(mainLooper).postDelayed({
                restartListening()
            }, 500)
        }
    }

    private fun restartListening(delayMs: Long = 300) {
        android.os.Handler(mainLooper).postDelayed({
            if (isServiceRunning) startListening()
        }, delayMs)
    }

    // ─── Notification ─────────────────────────────────────────────────────────

    private fun buildNotification(text: String): Notification {
        val mainIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, VoiceService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE
        )

        return Notification.Builder(this, ARIAApp.CHANNEL_ID_VOICE)
            .setContentTitle("ARIA")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(mainIntent)
            .addAction(android.R.drawable.ic_delete, "Stop", stopIntent)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIFICATION_ID, buildNotification(text))
    }

    private fun broadcastToUI(command: String, response: String) {
        sendBroadcast(Intent(ACTION_COMMAND_RESULT).apply {
            putExtra(EXTRA_COMMAND, command)
            putExtra(EXTRA_RESPONSE, response)
            setPackage(packageName)
        })
    }
}

package com.aria.assistant.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.aria.assistant.R
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class ChatMessage(
    val role: String,   // "aria" or "you"
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)

class ChatAdapter(private val messages: List<ChatMessage>) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        const val TYPE_USER = 0
        const val TYPE_ARIA = 1
    }

    override fun getItemViewType(position: Int) =
        if (messages[position].role == "you") TYPE_USER else TYPE_ARIA

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return if (viewType == TYPE_USER) {
            UserViewHolder(inflater.inflate(R.layout.item_message_user, parent, false))
        } else {
            AriaViewHolder(inflater.inflate(R.layout.item_message_aria, parent, false))
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val msg = messages[position]
        val timeStr = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(msg.timestamp))
        when (holder) {
            is UserViewHolder -> holder.bind(msg.text, timeStr)
            is AriaViewHolder -> holder.bind(msg.text, timeStr)
        }
    }

    override fun getItemCount() = messages.size

    class UserViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val tvText: TextView = view.findViewById(R.id.tvText)
        private val tvTime: TextView = view.findViewById(R.id.tvTime)
        fun bind(text: String, time: String) {
            tvText.text = text
            tvTime.text = time
        }
    }

    class AriaViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val tvText: TextView = view.findViewById(R.id.tvText)
        private val tvTime: TextView = view.findViewById(R.id.tvTime)
        fun bind(text: String, time: String) {
            tvText.text = text
            tvTime.text = time
        }
    }
}

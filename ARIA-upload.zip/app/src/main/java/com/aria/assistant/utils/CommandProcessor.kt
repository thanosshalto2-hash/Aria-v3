package com.aria.assistant.utils

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.provider.ContactsContract
import android.provider.Settings
import android.telephony.SmsManager
import android.util.Log
import com.aria.assistant.ai.AIManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * CommandProcessor — central dispatcher for all voice commands.
 *
 * Categories handled:
 *   CALL | SMS | ALARM | MEDIA | FLASHLIGHT | NAVIGATION
 *   WEATHER | WIFI | BLUETOOTH | BRIGHTNESS | OPEN APP
 *   SEARCH | WEB | AIRPLANE | BATTERY | SCREENSHOT | AI
 */
class CommandProcessor(private val context: Context) {

    private val scope = CoroutineScope(Dispatchers.IO)
    private val tts   = TTSManager(context)
    private val ai    = AIManager(context)
    private val prefs = PrefsManager(context)
    private var torchOn = false

    fun process(rawText: String, onResponse: (String) -> Unit) {
        val text = rawText.trim().lowercase()
        Log.d("ARIA_CMD", "Processing: \"$text\"")
        scope.launch {
            val result = try { dispatch(text) }
            catch (e: Exception) { Log.e("ARIA_CMD", "Error: ${e.message}"); "Something went wrong. Try again." }
            withContext(Dispatchers.Main) {
                if (prefs.voiceEnabled) tts.speak(result)
                onResponse(result)
            }
        }
    }

    private suspend fun dispatch(t: String): String = when {
        isCall(t)        -> handleCall(t)
        isSms(t)         -> handleSms(t)
        isAlarm(t)       -> AlarmHandler.handle(t, context)
        isMedia(t)       -> MediaHandler.handle(t, context)
        isTorch(t)       -> handleFlashlight(t)
        isNav(t)         -> handleNavigation(t)
        isWeather(t)     -> handleWeather()
        isWifi(t)        -> handleWifi()
        isBluetooth(t)   -> handleBluetooth()
        isBrightness(t)  -> handleBrightness()
        isAirplane(t)    -> handleAirplane()
        isBattery(t)     -> handleBattery()
        isScreenshot(t)  -> handleScreenshot()
        isOpen(t)        -> handleOpenApp(t)
        isSearch(t)      -> handleSearch(t)
        isWeb(t)         -> handleWebOpen(t)
        else             -> handleAI(t)
    }

    // classifiers
    private fun isCall(t: String)       = t.contains(Regex("\\b(call|dial|phone|ring)\\b"))
    private fun isSms(t: String)        = t.contains(Regex("\\b(send|text|message|sms)\\b.*(to |saying|:|-|[a-z]{2,})")) || t.contains(Regex("send (a )?(text|message|sms)"))
    private fun isAlarm(t: String)      = t.contains(Regex("\\b(set alarm|wake me|alarm for|set timer|timer for|remind me in)\\b"))
    private fun isMedia(t: String)      = t.contains(Regex("\\b(play|pause|stop music|next song|previous song|skip|volume up|volume down|mute|unmute|louder|quieter)\\b"))
    private fun isTorch(t: String)      = t.contains(Regex("\\b(flashlight|torch)\\b"))
    private fun isNav(t: String)        = t.contains(Regex("\\b(navigate|directions|take me to|how do i get to|maps to|route to)\\b"))
    private fun isWeather(t: String)    = t.contains(Regex("\\b(weather|temperature|forecast|will it rain)\\b"))
    private fun isWifi(t: String)       = t.contains(Regex("\\b(wifi|wi-fi)\\b"))
    private fun isBluetooth(t: String)  = t.contains(Regex("\\b(bluetooth)\\b"))
    private fun isBrightness(t: String) = t.contains(Regex("\\b(brightness|brighter|dimmer|dim screen)\\b"))
    private fun isAirplane(t: String)   = t.contains(Regex("\\b(airplane mode|flight mode)\\b"))
    private fun isBattery(t: String)    = t.contains(Regex("\\b(battery|charge level|how much battery)\\b"))
    private fun isScreenshot(t: String) = t.contains(Regex("\\b(screenshot|screen shot|capture screen)\\b"))
    private fun isOpen(t: String)       = t.contains(Regex("\\b(open|launch|start|run|switch to)\\b"))
    private fun isSearch(t: String)     = t.contains(Regex("\\b(search|google|look up|find)\\b"))
    private fun isWeb(t: String)        = t.contains(Regex("https?://|www\\.|open (the )?(website|site)"))

    // ── CALL ──────────────────────────────────────────────────────────────────
    private fun handleCall(text: String): String {
        val name = text.replace(Regex("\\b(call|dial|phone|ring|please|aria|hey)\\b"), "").trim()
            .split(" ").joinToString(" ") { it.replaceFirstChar { c -> c.uppercase() } }.trim()
        if (name.isBlank()) return "Who would you like to call?"
        val number = lookupContact(name)
        return if (number != null) {
            context.startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:$number")).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK })
            "Calling $name."
        } else {
            val digits = text.filter { it.isDigit() }
            if (digits.length >= 7) {
                context.startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:$digits")).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK })
                "Calling $digits."
            } else "I couldn't find $name in your contacts."
        }
    }

    // ── SMS ───────────────────────────────────────────────────────────────────
    private fun handleSms(text: String): String {
        val p1 = Regex("(?:send|text|message)\\s+(?:a (?:text|message|sms) )?(?:to )?([\\w\\s]+?)\\s+(?:saying|say|that|:|-|,)\\s+(.*)", RegexOption.IGNORE_CASE)
        val p2 = Regex("(?:text|message)\\s+([\\w]+)\\s+(.*)", RegexOption.IGNORE_CASE)
        val m  = p1.find(text) ?: p2.find(text)
            ?: return "Tell me who to text and what to say. E.g.: text John I'm on my way."
        val recipient = m.groupValues[1].trim()
        val body      = m.groupValues[2].trim()
        if (body.isBlank()) return "What would you like to say to $recipient?"
        val number = lookupContact(recipient) ?: recipient.filter { it.isDigit() }.takeIf { it.length >= 7 }
            ?: return "I couldn't find $recipient in your contacts."
        sendSMS(number, body)
        return "Message sent to $recipient."
    }

    // ── FLASHLIGHT ────────────────────────────────────────────────────────────
    private fun handleFlashlight(text: String): String {
        torchOn = if (text.contains("off")) false else if (text.contains("on")) true else !torchOn
        return try {
            val cam = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            cam.setTorchMode(cam.cameraIdList[0], torchOn)
            if (torchOn) "Flashlight on." else "Flashlight off."
        } catch (e: Exception) { "Couldn't control the flashlight." }
    }

    // ── NAVIGATION ────────────────────────────────────────────────────────────
    private fun handleNavigation(text: String): String {
        val dest = text.replace(Regex("\\b(navigate|directions|take me to|how do i get to|maps to|route to|open maps|aria|hey)\\b"), "").trim()
        val uri  = if (dest.isBlank()) Uri.parse("geo:0,0") else Uri.parse("google.navigation:q=${Uri.encode(dest)}&mode=d")
        return try {
            context.startActivity(Intent(Intent.ACTION_VIEW, uri).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK })
            if (dest.isBlank()) "Opening Maps." else "Navigating to $dest."
        } catch (e: Exception) {
            val fallback = Uri.parse("https://maps.google.com/?q=${Uri.encode(dest)}")
            context.startActivity(Intent(Intent.ACTION_VIEW, fallback).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK })
            "Opening Maps to $dest."
        }
    }

    // ── WEATHER ───────────────────────────────────────────────────────────────
    private fun handleWeather(): String {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=weather+today")).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK })
        return "Opening weather."
    }

    // ── WIFI ──────────────────────────────────────────────────────────────────
    private fun handleWifi(): String {
        return try {
            context.startActivity(Intent(Settings.Panel.ACTION_WIFI).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK })
            "Opening WiFi panel."
        } catch (e: Exception) {
            context.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK })
            "Opening WiFi settings."
        }
    }

    // ── BLUETOOTH ─────────────────────────────────────────────────────────────
    private fun handleBluetooth(): String {
        return try {
            context.startActivity(Intent(Settings.Panel.ACTION_BLUETOOTH).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK })
            "Opening Bluetooth panel."
        } catch (e: Exception) {
            context.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK })
            "Opening Bluetooth settings."
        }
    }

    // ── BRIGHTNESS ────────────────────────────────────────────────────────────
    private fun handleBrightness(): String {
        context.startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK })
        return "Opening display settings."
    }

    // ── AIRPLANE ──────────────────────────────────────────────────────────────
    private fun handleAirplane(): String {
        context.startActivity(Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK })
        return "Opening airplane mode settings."
    }

    // ── BATTERY ───────────────────────────────────────────────────────────────
    private fun handleBattery(): String {
        return try {
            context.startActivity(Intent(Intent.ACTION_POWER_USAGE_SUMMARY).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK })
            "Opening battery usage."
        } catch (e: Exception) {
            context.startActivity(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK })
            "Opening battery settings."
        }
    }

    // ── SCREENSHOT ────────────────────────────────────────────────────────────
    private fun handleScreenshot(): String {
        return try {
            Runtime.getRuntime().exec(arrayOf("input", "keyevent", "KEYCODE_SYSRQ")).waitFor()
            "Screenshot taken."
        } catch (e: Exception) {
            "Use Volume Down + Power button to take a screenshot."
        }
    }

    // ── OPEN APP ──────────────────────────────────────────────────────────────
    private fun handleOpenApp(text: String): String {
        val appName = text.replace(Regex("\\b(open|launch|start|run|switch to|please|aria|hey|app)\\b"), "").trim()
        if (appName.isBlank()) return "Which app would you like to open?"
        val pm   = context.packageManager
        val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        val match = apps.firstOrNull { pm.getApplicationLabel(it).toString().lowercase() == appName }
            ?: apps.firstOrNull {
                val label = pm.getApplicationLabel(it).toString().lowercase()
                label.contains(appName) || (appName.length >= 4 && label.startsWith(appName.take(4)))
            }
        return if (match != null) {
            val intent = pm.getLaunchIntentForPackage(match.packageName)
            if (intent != null) {
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                context.startActivity(intent)
                "Opening ${pm.getApplicationLabel(match)}."
            } else "Couldn't open ${pm.getApplicationLabel(match)}."
        } else "I couldn't find \"$appName\" on your phone."
    }

    // ── SEARCH ────────────────────────────────────────────────────────────────
    private fun handleSearch(text: String): String {
        val query = text.replace(Regex("\\b(search|google|look up|find|search for|please|aria|hey)\\b"), "").trim()
        if (query.isBlank()) return "What would you like to search for?"
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=${Uri.encode(query)}")).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK })
        return "Searching for \"$query\"."
    }

    // ── WEB ───────────────────────────────────────────────────────────────────
    private fun handleWebOpen(text: String): String {
        val raw = Regex("(https?://[^\\s]+|www\\.[^\\s]+)").find(text)?.value
            ?: text.replace(Regex("\\b(open|go to|website|site|page|url|please|aria|hey)\\b"), "").trim()
        val url = when {
            raw.startsWith("http") -> raw
            raw.contains(".")      -> "https://$raw"
            else                   -> return "I couldn't find a valid URL in that."
        }
        return try {
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK })
            "Opening $url."
        } catch (e: Exception) { "Couldn't open that URL." }
    }

    // ── AI ────────────────────────────────────────────────────────────────────
    private suspend fun handleAI(text: String): String {
        val clean = text.replace(Regex("\\b(ask|tell me|hey aria|aria|ok aria)\\b"), "").trim().ifBlank { text }
        return ai.ask(clean)
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    private fun lookupContact(name: String): String? {
        if (name.isBlank()) return null
        val projection = arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER)
        context.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, projection, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val n = c.getString(0) ?: continue
                val num = c.getString(1) ?: continue
                if (n.lowercase().contains(name.lowercase()) || name.lowercase().contains(n.lowercase()))
                    return num.replace(Regex("[^\\d+]"), "")
            }
        }
        return null
    }

    private fun sendSMS(number: String, body: String) {
        try {
            @Suppress("DEPRECATION")
            val sms = SmsManager.getDefault()
            sms.sendMultipartTextMessage(number, null, sms.divideMessage(body), null, null)
        } catch (e: Exception) { Log.e("ARIA_CMD", "SMS failed: ${e.message}") }
    }

    fun stopTTS() = tts.stop()
    fun clearAIHistory() = ai.clearHistory()
}

# ARIA — Personal Android Voice Assistant

A fully self-contained Android voice assistant. No subscription. Runs forever in the background. Controls your phone by voice.

---

## What it does

| Voice Command | Action |
|---|---|
| "Hey ARIA, call Mom" | Dials Mom from your contacts |
| "Hey ARIA, text John: I'll be late" | Sends SMS to John |
| "Hey ARIA, open WhatsApp" | Launches WhatsApp |
| "Hey ARIA, search quantum physics" | Opens Google search |
| "Hey ARIA, open youtube.com" | Opens URL in browser |
| "Hey ARIA, what's the capital of Japan?" | AI answers via voice |
| "Hey ARIA, write me a poem about rain" | AI generates, speaks it |
| "Hey ARIA, remind me to drink water" | Noted (+ AI help) |

Anything you don't map to a phone action → sent to AI (free).

---

## Setup: 3 paths to get free AI (no paid subscription)

### Option A — OpenRouter (RECOMMENDED — easiest, free tier)
1. Go to **https://openrouter.ai** → Sign up (free)
2. Create an API key (free)
3. Free models available: Mistral-7B, Llama-3-8B, Gemma-7B — all free with rate limits
4. In ARIA Settings → paste your key → select OpenRouter → Save

**Free tier limits:** ~200 requests/day per free model. More than enough for personal use.

### Option B — Ollama (100% offline, zero cost, no internet needed)
1. On your PC: install Ollama from **https://ollama.ai**
2. Run: `ollama pull llama3`
3. Run: `ollama serve` (keep running)
4. Make sure your phone and PC are on the same WiFi
5. In ARIA Settings → set Ollama Host to `http://YOUR_PC_IP:11434` → Save
6. Your phone sends queries to your PC's AI — completely private and free

**Find your PC IP:** Windows: `ipconfig` | Mac/Linux: `ifconfig`

### Option C — Direct API keys (if you already have them)
- OpenAI key → use GPT-4o-mini (cheap)
- Anthropic key → use Claude Haiku (cheap)
- Set in Settings → select provider

---

## Build & Install

### You need:
- A PC (Windows, Mac, or Linux)
- Android Studio (free): https://developer.android.com/studio
- Your Android phone with **USB debugging enabled**

### Steps:

**1. Enable USB debugging on your phone:**
- Settings → About Phone → tap "Build Number" 7 times
- Settings → Developer Options → Enable USB Debugging

**2. Install Android Studio**
Download and install from https://developer.android.com/studio

**3. Open the project**
- Open Android Studio
- File → Open → select the `ARIA-Android` folder
- Wait for Gradle sync to finish (2-5 minutes first time)

**4. Connect your phone via USB**
- Plug in with USB cable
- Accept the "Allow USB debugging?" prompt on your phone

**5. Run**
- Click the green ▶ Play button in Android Studio
- Select your phone from the device list
- App installs and launches automatically

**6. Grant permissions**
When the app opens, grant ALL permissions:
- Microphone (required for voice)
- Phone (for calls)
- Contacts (to find names)
- SMS (for texts)
- Display over other apps (for overlay — optional)

**7. Set up AI**
- Tap the ⚙️ Settings icon
- Choose your AI provider
- Enter API key (or Ollama host)
- Save

**8. Say "Hey ARIA"** — you're live.

---

## Project Structure

```
ARIA-Android/
├── app/src/main/
│   ├── java/com/aria/assistant/
│   │   ├── ARIAApp.kt                  — App class, notification channels
│   │   ├── ai/
│   │   │   └── AIManager.kt            — OpenRouter / Ollama / OpenAI / Anthropic
│   │   ├── service/
│   │   │   ├── VoiceService.kt         — Background listener, wake word detection
│   │   │   └── BootReceiver.kt         — Auto-start on reboot
│   │   ├── ui/
│   │   │   ├── MainActivity.kt         — Main chat UI
│   │   │   ├── SettingsActivity.kt     — All settings
│   │   │   ├── ChatAdapter.kt          — RecyclerView adapter
│   │   │   └── WaveformView.kt         — Animated listening indicator
│   │   └── utils/
│   │       ├── CommandProcessor.kt     — Intent classification + action dispatch
│   │       ├── TTSManager.kt           — Text-to-speech
│   │       └── PrefsManager.kt         — SharedPreferences wrapper
│   ├── res/
│   │   ├── layout/                     — All XML layouts
│   │   ├── values/                     — Colors, themes, strings
│   │   └── drawable/                   — Button and card backgrounds
│   └── AndroidManifest.xml             — Permissions + component declarations
├── build.gradle
├── settings.gradle
└── gradle.properties
```

---

## How the voice pipeline works

```
Microphone
    ↓
Android SpeechRecognizer (on-device, free)
    ↓
VoiceService.kt — detects wake word in partial results
    ↓
CommandProcessor.kt — classifies intent:
    ├── CALL → contacts lookup → ACTION_CALL
    ├── SMS  → contacts lookup → SmsManager
    ├── OPEN → PackageManager fuzzy match → launch intent
    ├── SEARCH → Google URL → browser intent
    ├── WEB  → direct URL → browser intent
    └── AI   → AIManager → OpenRouter/Ollama/OpenAI/Anthropic
                    ↓
               TTSManager (Android TTS, speaks response)
                    ↓
               VoiceService restarts listener
```

---

## Customizing the wake word

In Settings, change "Wake word" to anything:
- "hey aria" (default)
- "ok computer"
- "yo"
- Your name

---

## Troubleshooting

**"Speech recognition not available"**
→ Install Google app and enable "Google Speech Services" in Settings → Apps

**AI not responding**
→ Check your API key in Settings. For OpenRouter, ensure you used a free model like `mistralai/mistral-7b-instruct:free`

**Calls not working**
→ Make sure CALL_PHONE permission was granted. Settings → Apps → ARIA → Permissions

**Service stops in background**
→ Settings → Battery → ARIA → set to "Unrestricted" or disable battery optimization for ARIA

**Can't find contacts**
→ Grant READ_CONTACTS permission. Settings → Apps → ARIA → Permissions

---

## Adding more commands

In `CommandProcessor.kt`, add a new classifier and handler:

```kotlin
// Classifier
private fun isAlarmCommand(t: String) =
    t.contains(Regex("set alarm|wake me|alarm for"))

// Handler
private fun handleAlarm(text: String): String {
    // parse time, use AlarmManager
    return "Alarm set."
}

// In the when() block:
isAlarmCommand(text) -> handleAlarm(text)
```

---

Built with Kotlin · Android SpeechRecognizer · OkHttp · OpenRouter free tier
No subscriptions. No cloud dependency (with Ollama). Runs forever.
